(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.tagline_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#848484").s().p("AjnBcQgNgGAAgPQgBgJAHgGQAFgGALgEQgNgFAAgLQAAgHAFgEQAEgEAGgCQgIgEgFgJQgFgHAAgKQAAgPAKgJQALgKAUAAIANABIAjAAQAEAAAAAGIAAADQAAAGgEAAIgPAAQAHAIAAALQAAAPgKAJQgLAKgTAAIgCAAQgGAAgFABQgGADAAAEQAAAFAKACIAYAEQAiAGAAAXQAAAOgNAIQgOAKgYAAQgVAAgLgGgAjcA5QgHAGAAAGQAAAHAJAEQAHADAOAAQAOAAAIgFQAJgFAAgHQAAgIgNgDIgcgFQgHADgGAEgAjcgRQAAAUAXAAQAWAAABgUQAAgUgXAAQgXAAAAAUgAn7BcQgNgGAAgPQgCgRAXgIQgMgFAAgLQAAgHAFgEQADgEAHgCQgJgEgFgJQgFgHABgKQAAgPAKgJQALgKATAAIANABIAjAAQAEAAAAAGIAAADQAAAGgEAAIgOAAQAHAIAAALQAAAPgKAJQgLAKgTAAIgCAAQgGAAgFABQgGADAAAEQAAAFALACIAXAEQAiAGAAAXQAAAOgNAIQgNAKgYAAQgWAAgLgGgAnxA5QgHAGAAAGQAAAOAeAAQAOAAAIgFQAJgFAAgHQAAgIgOgDIgbgFQgIADgFAEgAnxgRQAAAUAXAAQAWAAAAgUQAAgUgWAAQgXAAAAAUgArZBcQgMgGAAgPQgBgJAGgGQAFgGALgEQgMgFAAgLQAAgLAPgGQgJgEgFgJQgFgHAAgKQAAgPALgJQALgKATAAIANABIAjAAQAEAAAAAGIAAADQAAAGgEAAIgOAAQAHAIAAALQAAAPgKAJQgLAKgTAAIgCAAQgGAAgFABQgGADAAAEQAAAFAKACIAYAEQAiAGAAAXQAAAOgNAIQgOAKgYAAQgWAAgLgGgArOA5QgHAGAAAGQAAAOAfAAQANAAAJgFQAIgFAAgHQAAgIgNgDIgbgFQgIADgGAEgArOgRQAAAUAXAAQAXAAAAgUQAAgUgXAAQgXAAAAAUgAObAzQgJgIAAgPIgBhAIgKAAQgDAAAAgGIAAgCQAAgHADAAIALAAIACgVQAAgFAGAAIACAAQAGAAAAAFIAAAVIARAAQAEAAAAAHIAAACQAAAGgEAAIgRAAIAAA+QAAAPALAAIAJgBQACAAABAEIABAGQAAAGgOAAQgKAAgHgFgAHBAzQgJgIAAgPIgBhAIgKAAQgEAAAAgGIAAgCQAAgHAEAAIAKAAIADgVQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQABgBABAAQAAAAABAAIACAAQAGAAAAAFIAAAVIARAAQAEAAAAAHIAAACQAAAGgEAAIgRAAIAAA+QAAAPALAAIAJgBQABAAACAEIABAGQAAAGgOAAQgLAAgGgFgAg9AzQgJgIAAgPIgBhAIgKAAQgEAAAAgGIAAgCQAAgHAEAAIAKAAIADgVQAAgFAGAAIACAAQAGAAAAAFIAAAVIARAAQAEAAAAAHIAAACQAAAGgEAAIgRAAIAAA+QAAAPALAAIAJgBQABAAACAEIABAGQAAAGgOAAQgLAAgGgFgAMnAqQgNgNAAgbQAAgaAMgOQAMgOAXAAQAVAAALAOQAKANAAAZQAAACgCADQgDADgCAAIhAAAQACARAHAIQAIAIAOAAQALAAAKgEIAJgFQACAAADAFQACAEAAACQAAAEgKAEQgMAEgOAAQgZAAgMgNgAMsgFIA1AAQAAgggYAAQgaAAgDAggAL2A3QgIAAAAgEIAAhEQAAgJgFgFQgGgFgKAAQgHAAgHAEQgHADgEAHIAABJQAAAEgJAAIAAAAQgIAAAAgEIAAhHQABgMgDgNQAAgDAEgBIAHgBQADAAABAFIACAJQAGgHAJgEQAIgEAJgBQAQAAAIAJQAJAJAAAPIAABGQAAAEgIAAgAH+AqQgMgNAAgbQAAgaAMgOQAMgOAXAAQAVAAALAOQAKANAAAZQAAACgCADQgDADgCAAIhAAAQABARAIAIQAHAIAPAAQALAAAKgEIAJgFQACAAACAFQADAEAAACQAAAEgLAEQgLAEgOAAQgZAAgNgNgAIEgFIA1AAQAAgggYAAQgaAAgDAggAGJA3QgIAAAAgEIAAhEQAAgJgFgFQgGgFgKAAQgGAAgHAEQgHADgFAHIAABJQAAAEgIAAIgBAAQgIAAAAgEIAAhHQABgNgDgMQAAgDAFgBIAGgBQADAAACAFIACAJQAGgHAIgEQAIgEAKgBQAPAAAJAJQAIAJAAAPIAABGQAAAEgIAAgAEUA3QgJAAAAgEIAAiFQAAgEAJAAIABAAQAJAAAAAEIAACFQAAAEgJAAgAByAqQgMgNAAgbQgBgaAMgOQAMgOAYAAQAVAAAKAOQALANAAAZQAAACgDADQgDADgBAAIhBAAQACARAHAIQAIAIAPAAQAKAAAKgEIAJgFQACAAADAFQACAEAAACQAAAEgKAEQgLAEgPAAQgZAAgMgNgAB4gFIA0AAQAAgggYAAQgaAAgCAggABCA3QgIAAAAgEIAAhEQAAgJgFgFQgGgFgKAAQgJAAgJAHIgHAHIAABJQAAAEgJAAIAAAAQgHAAAAgEIAAiPQAAgFAHAAIAAAAQAJAAAAAFIAAA2QAGgGAIgEQAIgDAJgBQANAAAIAGQALAJAAASIAABGQAAAEgIAAgAkUA3QgIAAAAgEIAAhEQAAgJgFgFQgGgFgKAAQgHAAgHAEQgHADgEAHIAABJQAAAEgJAAIAAAAQgJAAAAgEIABhHQAAgNgCgMQAAgDAEgBIAGgBQAEAAABAFIACAJQAGgHAJgEQAIgEAJgBQAQAAAIAJQAJAJAAAPIAABGQAAAEgIAAgAprAwQgKgIAAgPQAAgXAWgHQAPgFAeAAIAAgKQAAgHgFgFQgGgFgLAAQgLAAgLAEIgKAEQgCAAgCgEQgDgEAAgCQAAgEAMgEQAMgFAOAAQATAAALAJQAKAIAAAPIAAAsQAAAMADAOQAAACgFABIgGABQgDAAgCgFIgCgJQgHAHgJAEQgJAEgJAAQgQAAgJgHgApSAFQgRAFAAAOQAAARARAAQAKAAAJgFQAFgCAIgHIAAgYQgXAAgJACgAsGA3QgIAAAAgEIAAhEQAAgJgGgFQgFgFgKAAQgHAAgHAEQgHADgFAHIAABJQAAAEgIAAIAAAAQgJAAAAgEIABhHIAAAAQAAgMgDgNQAAgDAFgBIAGgBQADAAACAFIACAJQAGgHAJgEQAIgEAJgBQAQAAAIAJQAJAJAAAPIAABGQAAAEgIAAgAuzA3IgEgBIgCgEIAAgBIAAiBIAAAAIABgEQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAIBIAAQAEAAAAAGIAAADQAAAGgEAAIg7AAIAAAuIA1AAQADAAAAAHIAAADQAAAGgDAAIg1AAIAAAxIA7AAQAEAAAAAGIAAADQAAAGgEAAgAJvA3QgJAAAAgFIAAhGQABgNgDgMQAAgDAEgBIAHgBQADAAACAFIACAJQALgQAMAAQAGAAADADQADACAAADIgBAHQAAABgBAAQAAABAAABQgBAAAAABQAAAAgBAAIgEgBIgHgBQgHAAgGAGIgGAGIAABJQAAAFgIAAgAmHA3QgJAAAAgFIAAhhQAAgEAJAAIAAAAQAJAAAAAEIAABhQAAAFgJAAgAmIhMQgIAAAAgEIAAgMQAAgFAIAAIADAAQAIAAAAAFIAAAMQAAAEgIAAg");
	this.shape.setTransform(95.4,9.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.tagline_mc, new cjs.Rectangle(0,0,190.9,19.6), null);


(lib.ctashine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.502)","rgba(255,255,255,0)"],[0.224,0.518,0.788],-28.4,-16.4,28.4,16.4).s().p("AlHGqIAAtTIKPAAIAANTg");
	this.shape.setTransform(32.8,42.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctashine, new cjs.Rectangle(0,0,65.6,85.1), null);


(lib.headline_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApSCSQgrgvAAhfQAAjDCuAAQAnAAAgAMQAgAKAAAMQAAAHgHALQgGANgFAAQgLgGgOgGQgbgMggABQhFAAgeAnQgbAjAABKQAABGAYAlQAeAtBCAAQAVAAATgCQASgCALgDIAAhsIg+AAQgLAAAAgQIAAgJQAAgJACgDQADgDAGAAIBeAAQAIAAAEAEQAEACAAAJIAACPQAAAUglAKQgeAIg1AAQhSAAgpgugACsCcQgggjAAhJQAAhFAgglQAfgmA+ABQA3gBAcAlQAcAjAABDQAAAGgHAIQgGAJgFAAIiqAAQAEAtATAUQAUAWAoAAQAdAAAagMIAYgLQAFAAAHALQAHALAAAEQAAALgcALQgfANgmAAQhDAAghgjgAC8AcICMAAQAAhUhAgBQhGABgGBUgAhqCcQgggjAAhJQgBhFAgglQAggmA+ABQA2gBAcAlQAcAjAABDQAAAGgHAIQgGAJgFAAIipAAQADAtAUAUQAUAWAoAAQAcAAAagMIAYgLQAFAAAHALQAHALAAAEQAAALgcALQgfANglAAQhDAAghgjgAhbAcICMAAQAAhUhAgBQhGABgGBUgAkSC/QgVAAAAgNIAAi8QAAgjgHggQAAgIAMgDQAJgDAJAAQAIAAAFANIAGAXQAOgUAPgKQAQgKARAAQAPgBAIAHQAIAFAAAJQAAAKgDAJQgDALgFgBIgKgCQgJgDgLAAQgRAAgSARIgOAQIAADEQAAANgWAAgAJnC9QgWAAAAgMIAAi2QAAgZgOgNQgPgOgaAAQgSAAgTAKQgSALgNAQIAADFQAAAMgWAAIgCAAQgVAAAAgMIAAi7QAAgjgGggQAAgIAMgDQAIgDAJAAQAIAAAFANQACAFAEASQARgTAWgLQAWgLAXABQApAAAXAWQAXAYAAApIAAC5QAAAMgVAAg");
	this.shape.setTransform(63.8,21.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#88CE02").s().p("AjlCoQghgmAAhGQAAhGAhglQAhglBAAAQBAAAAhAlQAhAlAABGQAABGghAmQghAlhAAAQhAAAghglgAi2A8QAABSAyAAQAaAAAMgVQAMgUAAgpQAAgpgMgTQgMgVgaAAQgyAAAABRgABCCpQgigkAAhIQAAhIAhgkQAiglBHAAQAhAAAaAJQAfALAAARQAAAIgLARQgLARgHAAIgJgEQgWgMgZAAQggAAgPAUQgOATAAAqQAAAqANAUQAOAUAfAAQAcAAAYgNIAKgDQAIAAAKARQAKAPAAAJQAAATgpALQgcAHgZAAQhFAAghgjgAn+C7QgggOAAgQQAAgMAMgSQAMgRAJAAQADAAAHAEIARAIQAaANAaAAQAVAAANgIQARgKAAgWQAAgUgYgPIgZgMIgdgMQgkgQgRgUQgYgaAAgrQAAg4AogdQAigaA1AAQApAAAdAMQAbAMAAAOQAAAMgKARQgKASgKAAIgTgHQgTgHgVAAQgcAAgNAMQgKAIAAAMQAAAUAZAOQAOAIAnAPQAkAQARATQAZAbAAArQAAA+gnAfQggAagzAAQg4AAgmgRgAHqDKQgNAAgHgCQgJgCgEgGIhKh7IgCAAIAAB0QAAAJgIAEQgIAEgRAAIgPAAQgRAAgIgEQgHgEAAgJIAAl0IgBAAQAAgIAIgFQAIgEARAAIAPAAQARAAAIAEQAHAFAAAIIAADUIACABIBChhQAEgGAJgCQAGgCAOAAIATAAQAfAAAAAJQgBAGgEAEIhLBqIBYCLIADAGIABAFQAAAIgeAAg");
	this.shape_1.setTransform(188.3,20.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.headline_mc, new cjs.Rectangle(0,0,242.6,41), null);


(lib.Path_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AALBQQgqgBgugGIgIiQIAmgIQA6AbBBACQgDARgBAWQgCAqAOAaQANAXhKAAIgMAAg");
	this.shape.setTransform(8.6,8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_21, new cjs.Rectangle(0,0,17.3,16.1), null);


(lib.Path_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhYA1QAbgIAKgXQALgZgTgYQgOgRgTgRQgHgIAXgBQAXgBBMAoQAmAUAiATIhGA/g");
	this.shape.setTransform(9.5,7.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_20, new cjs.Rectangle(0.1,0,18.9,14.3), null);


(lib.Path_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgXAsQhdgBg8gJQgdgFgMgEIAFgyQA8AWB3gDQA0gCA2gGQBAgJApgOQAlgNACARQABAIgGALIggAdQgUAIgjAHQhAAOhGAAIgOAAg");
	this.shape.setTransform(21.8,4.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,43.5,8.7), null);


(lib.Path_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUAkQhdgBgygGQgZgEgHgDIgCgyQA9AWB2gDQBOgDAXgCQA+gFAmgPQAQgFgCAQQAAAHgEAJIgKARQgUAHgjAHQhAAMhFAAIgPAAg");
	this.shape.setTransform(19.8,3.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0.1,39.5,7.2), null);


(lib.Path_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjiGyQgEgNgCgRIgGgvQgOiMgohkQguh1hNgvQB3hBD8h7QEdiLB9gyQA6gYgJAJQgrArgMAXQgRAeAAAqQAAAqgCACQh4Bqh8CDQj3EDhKDLQgDgDABgFg");
	this.shape.setTransform(41.6,44.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0.3,83.2,88.5), null);


(lib.Path_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAPCAQiChljXAHQCVgKDWiTQCrh3B1iDQALgLgCAMIgMAqQgcBYAAAuQACDEgNBkQgTCZg/B/QhSiuhkhOg");
	this.shape.setTransform(33.1,38);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_8, new cjs.Rectangle(0,0.1,66.2,75.9), null);


(lib.Path_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAkEdQgDg3gHg7QgMh2gQgUQgPgTg2gqQg/gzgKgKQgRgQAWgmQAdgwgCgaQgCgiAShFQAJgjAKgbIC4CTQgigOgXAgQgXAfAJApQAGAbA7BJQA3BXgEB1QgDBjgSBJQgJAkgJAQg");
	this.shape.setTransform(15.4,38.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0.2,0,30.5,76.6), null);


(lib.Path_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ah0F4QBwiPAGgaQAEgRgdhrIgfhoIBtluQgDBhASCjIAdDiQAIA2AKAyQADAegVAfQggAugrBOg");
	this.shape.setTransform(11.7,38.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_5, new cjs.Rectangle(0,0,23.4,77.6), null);


(lib.Path_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag0A5QgrgOgagYQgcgZgVguIAuACIATAvICcAbIB0hcQADASABAVQABApgOARQghAlhPADIgSAAQgwAAgggMg");
	this.shape.setTransform(17.1,6.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_4, new cjs.Rectangle(0,0,34.2,13.9), null);


(lib.Path = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgqBAIgYgrIBChYQAGAgALAcQAQAnAWASQALALABADQABAEgJAAg");
	this.shape.setTransform(6.7,6.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0,0,13.4,13.6), null);


(lib.ctashinecontainer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.ctashine();
	this.instance.parent = this;
	this.instance.setTransform(32.8,42.6,1,1,0,0,0,32.8,42.6);
	this.instance.alpha = 0.648;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctashinecontainer, new cjs.Rectangle(0,0,65.6,85.1), null);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Path();
	this.instance.parent = this;
	this.instance.setTransform(276.3,125.5,1,1,0,0,0,6.7,6.8);
	this.instance.alpha = 0.398;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AH0HgQhPhqhagoQhlgtjBgDQjLgDiGhiQiThqgYjDQgRiXgchUQgihnhCg5IAxgfQA8A6AkBoQAfBdAMB4QAUDTB0BhQB7BpD9gGQClgFBxA5QBjAxBHBmQAPAWAZAOQAXANAVAAQAAAAAAAAQABABAAAAQAAAAgBABQAAAAAAABQgCADACACIgTArQg9gNgkgyg");
	this.shape.setTransform(120.2,199.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#88CE02").s().p("AD0AsQgEgDgRgEQgOgFgHgEIgagOQgPgGgQABQgZADhVAXQgwANgzgMQhHgUgcgGQgugKg7ADIAEgyQBEAdCmAmQAmAIBVg2QAkgXAtALQApALAaAcQAcAgAAALQAAAEgGAAQgGAAgNgEg");
	this.shape_1.setTransform(239.9,64.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1.6,0,1).p("AjxgwQAjAWBSAZQA/ASAqAHQAWAFArgXQAXgLAkgVQAdgNAgADQAqAGApAkQAGAGgUAaQgOgDgRgHQgagPgdADQgbAEhRAWQguAMg0gLQhJgUgcgGQgsgKg3AD");
	this.shape_2.setTransform(239.4,63.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#88CE02").s().p("Ag1ArQhJgTgcgGQgsgKg3ACIAQg6QAjAXBSAZQA/ARAqAIQAWAFArgXQAXgLAkgVQAdgOAgAEQAqAFApAkQAGAGgUAbQgOgDgRgHQgagPgdADQgbADhRAWQgZAHgZAAQgYAAgYgGg");
	this.shape_3.setTransform(239,63.7);

	this.instance_1 = new lib.Path_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(231.1,50,1,1,0,0,0,17.1,6.9);
	this.instance_1.alpha = 0.398;

	this.instance_2 = new lib.Path_5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(235.7,226.1,1,1,0,0,0,11.7,38.8);
	this.instance_2.alpha = 0.398;

	this.instance_3 = new lib.Path_6();
	this.instance_3.parent = this;
	this.instance_3.setTransform(202,124.2,1,1,0,0,0,15.4,38.3);
	this.instance_3.alpha = 0.398;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AnKDDQDbiIF8izQC+hbCTg/IAEAKQAEALgEANQgOAnhaAdQhoAglRCwQlHCshdBDg");
	this.shape_4.setTransform(90.1,131.9);

	this.instance_4 = new lib.Path_8();
	this.instance_4.parent = this;
	this.instance_4.setTransform(161.7,220.2,1,1,0,0,0,33,38);
	this.instance_4.alpha = 0.398;

	this.instance_5 = new lib.Path_9();
	this.instance_5.parent = this;
	this.instance_5.setTransform(101.2,146.9,1,1,0,0,0,41.6,44.5);
	this.instance_5.alpha = 0.398;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EFEFEF").s().p("AgsBpQgKgFABgHQACgIgMgJQgvghgNgXQgSgfAPg0QABgKAPgOIAlgdQAvgDAnALQAsANAcAeIAhAfQASATgCANQAAAGgXAbIgPASIgPAPIgrAhQgIAIgMAIQgJAFgKAAQgTAAgYgNg");
	this.shape_5.setTransform(197.2,162.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ABGAuQgGgIgjgYQgkgXgRgHQgSgIgTgLQgSgLAAgDQAAgCAIAAIAIAAIA3AbQAxAZAVAWQAUAWgCAFQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAQgDAAgFgGg");
	this.shape_6.setTransform(266.4,71.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgsATQg2gFgfgOQgfgNAGgFQAEgDAJAAQArAYBDADQAZACA8gEIAwgFQAsgHACABQAHABABAGQgIAEgQAFQghAJgrACIguACQgbAAgbgDg");
	this.shape_7.setTransform(204.9,64.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EFEFEF").s().p("AhJCVQgygZgNgRQgPgVAIgpQAHgbApgjQAcgaA1gjIgrAJQgTAFACgQQAFggAQgQQAWgYACgEQgHgHBAADQBAADANALIAAACQAAAJAMAgQAJAagFALQgDAFgIgFQgNgJgFgBQAPBWAgBOQAbA8hLANIghABQhDAAhAgNg");
	this.shape_8.setTransform(179.3,335);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EFEFEF").s().p("AhNEWQgxgIgYgMQAEgZAPjrQAKijAnh2QB0AjB1AMQgPBfglBXQgUAwgmBTQgNAkgDBYQgEBPgCAAQgRAEgUAAQgbAAgggGg");
	this.shape_9.setTransform(189.9,288.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AhzAwQhpgcgggRIgMgJIgIhAQADAMBYApQBfArA9AMQA4AKBygFQBggFAggHIgEAdQg3AIhLADIgtABQh5AAhYgYg");
	this.shape_10.setTransform(236.2,147.9);

	this.instance_6 = new lib.Path_18();
	this.instance_6.parent = this;
	this.instance_6.setTransform(242.2,286.3,1,1,0,0,0,19.8,3.6);
	this.instance_6.alpha = 0.301;

	this.instance_7 = new lib.Path_19();
	this.instance_7.parent = this;
	this.instance_7.setTransform(243.3,275.9,1,1,0,0,0,21.8,4.4);
	this.instance_7.alpha = 0.301;

	this.instance_8 = new lib.Path_20();
	this.instance_8.parent = this;
	this.instance_8.setTransform(292.4,340.5,1,1,0,0,0,9.6,7.1);
	this.instance_8.alpha = 0.301;

	this.instance_9 = new lib.Path_21();
	this.instance_9.parent = this;
	this.instance_9.setTransform(234.3,336.3,1,1,0,0,0,8.6,8);
	this.instance_9.alpha = 0.301;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#88CE02").s().p("ADbGQQgkgDhlgPQhOgMhLgCIiagCQhSgCgNgqQgLggAfg/QAZgzADgjQACgagIhiQgGhJgchDQgmhdgDgKQgoiVASgYQABgCAVAIQAiAMA6AEQCDAECDgYQAVgGgCAOQgBAIgIAYIgcC4QgHAtAAB3QAABsAFAvQABAIBLApQBbAwAWARQAcAXBPAaQBQAbAKAHQAXAQgNAOQgOAQgxAHQgfAFggAAIgggBg");
	this.shape_11.setTransform(260.2,305.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("ADwGVQhHgCh+gNQh1gNgtAAQhuAAgVgCQhAgDgLgSQgMgRALgoQAKglAWgeQASgZACggIgChQQgCg6gWhNIgriEQgzidAihKIAVAHQAdAHAmAFQB4ANCmgaIggDVQgdDsAWB3IAwAkQBRAwChA6IA4AWQA4AcgCAkQABADgRADQgVADguAAIg0gBg");
	this.shape_12.setTransform(260.8,302.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EFEFEF").s().p("AhLDeQgPgFgOgKQghgxgFg9QgCgVgGgdQgFgbgCgQIgChRIAKhiQACgSAfgPQAogUBKAAQBFAAAsATQAjAPAGARQALA9gFA5IgDAwQgDAmgCAPQgBAQgGAcIgLA4QgFAagSAZQgRAYgRAFQgcAHgvAAQgrgBgggGg");
	this.shape_13.setTransform(231,27.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#001423").s().p("AADAJQgQgLgQgOIAcAOQARAIANALQgPAAgLgIg");
	this.shape_14.setTransform(190.3,173.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AF/BdQhxhFiSgHQh7gGiWAlQgkAJgPABQgcADgZgJQg5gTgugcQgpgZgVgbQgNgQgEgRIgBgNIAwAkQA3AnAfAQQAmASAjAAQAmAABQgWQB4gcB6ACQBbAABmArQAtAVALACQAiADAEgxIANAdQAMAhgLAQQgIANgSAJQgLAGgHAAIgFgBg");
	this.shape_15.setTransform(238.2,95.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#EFEFEF").s().p("AAeGKIiDhLQifhZgehJQgZg+gBgiQgCgjAWgaQAugzAYhbQAUhPAggUQArgcArAVQAgAQAdAoQgLgugkgeQgigVAAgDQAAhDA4gyQAygtBIgNQAxgKAfABQAgAAAeALQAgALAgAFQAtAJgEBOQgFBLgrBGQgBABgMgSQgMgSgBABQgUAkgJAMQgDBEgiBBQgpBMg8AVQgRAGgSgBQgTgCgPgJQgngZgqgPQA3ArAdAlQAgAnAYA3QAdBIAYAqQApBKA9A/QgSAagMANQgUAXgWAJQgrgnhMgsg");
	this.shape_16.setTransform(169.9,111.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAXGdIiGhAQiehNgrhlQgag5gGgbQgNgyAUgWQAmgnAOgYQARggAThGQAWhRAvgfQAWgQArgGQAFhSA7g4QAzgwBOgQQBVgQBCAQQA/ARAgAsQAhAtgIA9QgJBAg0BHQAMBuhEBPQgwA3hBAYQAQAZAMAiIAUA+QAfBWBOBcQgOAggjAhQgmAlgmAKQgxgqhPgog");
	this.shape_17.setTransform(165.4,110.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AibHDQhigYARg5QAHgZAVgnQAVgnABgHQAEgbAFgVQAJgnAVgXQAUhCABhTQAAgigHhrQgJhZAFhRQAGhnAbg1QAmAZBBAVQBwAkCAgGQgGA+gHAaQgVBJg5BVQgkA0gYBQQgaBXgGBoQABAQAHAgQADAdgPAbQAFAQAUAmIAgA6QAQAggLAPQgQAXhJABIgXABQhfAAg+gQg");
	this.shape_18.setTransform(185.8,304.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAHAlQhigMhAACIgyAAQg+gHgUgWQgUgWAagdIJCAxQAEAcgrAQQgiAMg2ACQgigCiBgPg");
	this.shape_19.setTransform(262.3,341);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("ABbAsQjBgWg4ACQiiADgogdIABgWIABgXIAXgEIK3A4IgCAlQg5AKhGAAQhAAAhMgIg");
	this.shape_20.setTransform(262.7,341.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AARBPQiWgCgkhBIgIg0IAOgTQAPgUADAAQATACBuAiQB0AlA6AIIALACIAJAEIgGAzQgEAGgWAFQgmAKhGAAIgVgBg");
	this.shape_21.setTransform(179.5,346.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgaCRQgMAAgRgFQgigKgUgVQgEgOAIgLQgrgkgMgZQgSglAOgnQACgLAsghIBBgvQA1ACAyAQQAeAKANAMQAIAHAOASIAmAkQAWAagFASQgCAKgIAIIgSARQgzA3gKAGIgzAiQgRAJgKADQgJACgLAAIgJAAg");
	this.shape_22.setTransform(197.6,163.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#EFEFEF").s().p("Ak1J2QgQjRAlhhQARgqAjgwIBOhjQgkh0AChyQAFjZBykxQC+gpBzBhQBBA3ASBCQgXAYgaBbQgPAzgZBjQgaBrgtBJQg5BdhiBCQABAogXAhQgNAUgdAcQgYAcgHAmQAMgPANgLQAOgLAAAFQgDBvgSA6QgRA1g4BZg");
	this.shape_23.setTransform(211,225.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AlQJxQgCgHgCgcQgEg5AAhqQAAhsAvhMQAQgaAegmQAogvALgQQgsiwAvjVQAVheBakAQDKgsCHBmQBDAzAbA8QgTBFgXCjQgSB7gkBLQgqBchLBEQglAigdAPQgDAjgTAdQgKAQgPAQQAIBKgSBKQgSBEguBNQgXAmgUAZg");
	this.shape_24.setTransform(208,227.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#EFEFEF").s().p("AjPB3QglgogigyIgagqIARhJQALgsALgbIAIhGQEJAAEEAZQAEAlgIAgQABA8ANA8QAEAUANA3QAKAnAAAWQAABMheARQgiAGg6ABIhkABQgQAEgQAAQheAAhkhtg");
	this.shape_25.setTransform(235.7,168.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AjVBhQgygogxgzIgngpIARhDQAOgyAJgcQAFgJABgJQAMgRE4AbQCdAOCaAQIAEBcQAAAKAJAqQAJArAAAOQgWAohEAqQhZA4h2AVQgQAEgSAAQhjAAiHhtg");
	this.shape_26.setTransform(233.5,170.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#EFEFEF").s().p("ABBGmQiagNhpgFQgXhegJhfQAngSAcghQgtAHgZgCQgYgEgcgPQgagPgrgpQgogngaghQgIAOgNAQQgZAigfABQgJgOAegyQAfgzgHgOQgghCAjirIAqifQAsAOAxAEQBNAFBIgHQBpgIA8ADQBlAGA9AiQA0gPA2ADQANABAYAMQAcAOAMADQBHATAuBcQAvBigbBhQgCAFgUAAQgbAAgQAFQAOBUglBOQglBLgOA0QgaBbAGBwQhsgFiagMg");
	this.shape_27.setTransform(230.4,107.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#EFEFEF").s().p("AhJLeQgEgxgJg9QgRh8gbhBIgvhXQgeg3gCgwQgEg5Aig5QAphDBFACQgChPgUg/IgshwQhDipgSkfIGGhbIAdCqQARBsADBMQALDWhYBiQAMA7gKA4QgIAogPAnQgNAggJA0QgEAVgIA6QgUB9gFA9QgFA3gJDPg");
	this.shape_28.setTransform(247.9,245.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AhOLUQgEgxgJg9QgSh8gahBQgFgMhAhaQgyhFACgvQAEg2ATgjQAagxBHg4QADgjgQg4QgXhJgNgxQg1jFALkDIGphFIASBJQATBbAIBWQAaERhdB2QAIAvgHAuQgHAvgXApIgNA7QgIAjgEAYIgvDZQgdCEgHCig");
	this.shape_29.setTransform(248.4,246.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("ABDG8QjWgeiJADIAGhFIAGAAIgOhTQgHgngIgfQhJgugsgnQhAg4gvhIQgqhEBPjKQAZhAAhhEIAdg5IBHAUQBSATA9gEQBqgJBKAFQByAGA8AiIA4gNQBDgKA2ANQBPAVBEBcQBQBqggBpQgDAIgRALQgSALgXAHIAFAqQABAwgSAjQgrBSgOAmQgjBegCBeQgGBNgEAXQg0gCjvggg");
	this.shape_30.setTransform(230.5,111.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#88CE02").s().p("AhDAPIgogfQANgKgFgCQAXgNAOAAQAVAAAJAZQAfgKAPAKIAdAeQAlgQAPALQAHAFAGAUQgrABgmAFIgPACQglAAgqgbg");
	this.shape_31.setTransform(270,70.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AhEApQglggAAABQAAgVgCgVQAAgCgIgHQgIgHAAgCIgEgEIATgIQAXgGAPAGQAQAFAOATQAHAKAEAJQAdgLAPAJQAEACAYAZQAhgGAQAMQAJAGAbApQgJgBgSAAQgkgBgtAIIgOABQgjAAgngZg");
	this.shape_32.setTransform(270.6,68.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#88CE02").s().p("AkmA+QAsg+BIgWQAcgLAUADQARADAXAPQgKgRgKgMQAQgIAagRQAWgLATADQAXAFAXARQAVAOAQARQgKgZgRgRQALgHAUgRQASgMASABQBVAHAtAsQAMAMAUAWQASARAUAHIizApQhtAZhpANQhGAJgtAAQhcAAAKglg");
	this.shape_33.setTransform(192.1,65.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AkvA0QAsg6A+gUQATgHAWgBQAVgBAJAFQAPgGASgMIAggVQAQgJAdAIQAUAFAOAIQARgKAdgUQAYgOAVAGQA7APAyAiQAyAhAlAvIixApQhyAQhuAFQgkACgeAAQiaAAANgug");
	this.shape_34.setTransform(190.8,63);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#EFEFEF").s().p("AhEH0QgYgGgagQIg+glQgUgLABgTQAFgUAAgJQACgKAIgIQAMgYAXgVIASgSQAXgSAYABQAcACAbgFQAbgFAHgIQAAgXgMgVIgYgjQghgvARhGQAFgPAogFQgvgJgMgFQgYgIgXgWQgogigJg1QgHgogOi1IgLiuIAYgLQAfgLAegFQBggQA2A1QA7A5ACBJQACAygaBAQAcAhAOAnQAWA+gVA6QgDAHgdARQghASgTAeQA8giAnAHQAmAGAOAtQATA/ghBQQgaBCgyA2IgCgGQgMAugIATQgVAwgnAqQgVAXgVADIgIAAQgOAAgZgGg");
	this.shape_35.setTransform(283.3,126.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AA2GQQgqg2hHgEQABgMgPgTQgVgVgKgNQgog0Aeg+QgzgMgRgnQgGgMgOhKQgGgoAQjcIARjVIAVgEQAbgDAbABQBWAHA2A0QA0AxAPBGQAQBGgcBDQAgAoAIAxQAJAygQAvQBeBSgVB5QgUBshiBfQgHgbgWgbg");
	this.shape_36.setTransform(286.6,118.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AApCCIgOgXQgCgDgJgFQgKgFgDgDIgFgMQgDgIgGgFQgEgEgHAAQgHgBgEgDQgEgEgFgJQgEgIgDgDQgCgCgKgDQgLgDgCgCQgCgCgzgTQgtgPADgMQAHgeARgXIAYgcQAdgcAYABIA3ADQAbAAANgLQAUgSA+AuQBBAvgEAtQgKAegTAkQgmBJgvAbQgKgFgFgLg");
	this.shape_37.setTransform(278.5,165.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("ACqCLQAMgogCgnQgBgVgEgQQgDgHAEgHQAKgPABgIQABgQgYgNQgVgLgxAMQhFARgZABQgbgBhDgRQgxgMgUALQgYANABAQQABAJAKAOQADAGgCAHQgEAQgBAWQgCAqAMAlIgTAAQgLhtgDgkQgDgwAFgHQAogqAYgMQAvgXBZgBQBbACAwAXQAgAQAgApQADAGgEAwIgOCOg");
	this.shape_38.setTransform(231,17);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AhKDMQgQgFgNgIIgtgiQgigaAAgTQAMh1gQh2QgEgOAGgQQAMgfAxgJQA/gMA8gEQA+ACA+AOQAxAJAMAfQAGAQgEAOQgQB2AMB1QAAASgiAbIgnAdQgVAPgOACQgjAHgoAAQglAAglgGg");
	this.shape_39.setTransform(230.9,29.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAzBlIgygBQgxAAgLgBQgfgCgMgLQgQgOgbgbIgsgtQADgaADgdIACgXQAlgWCiAAQCkAAADAWQACARADBFQgUAZgeAYQggAbgYAMQgHAFgWAAIgEAAg");
	this.shape_40.setTransform(230.6,42.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EFEFEF").s().p("AijB4QgMhBgpg3QgmgqABgHQAHggACgfQAEgjABgsIABglQAkgVCJAEQCJAFADAXQAEAZAEAyQAFA4ABAoQABAcgCAjQAAAYATAHQBNAfBGAvQhZBjh2ASQgUADgSAAQhzAAg5h+g");
	this.shape_41.setTransform(238.3,57.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AAHDTQh5gNhYguQhlg1gehWQASgIA0gMQAlgJABgHQAQhVAGhUQAlgWClAAQCjAAADAWQAFAfAFCgQACArADAHQADAIAXAJQBDAdA9AoQgZAshgAWQg9AOhFAAQglAAgngEg");
	this.shape_42.setTransform(232.7,54.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AANCPQg4gGhIgnQgWgNgSglQgRgiACgRQAAgrAhgcIAVgbQAagbAYABQA2ADAOgBQAqgBANgLQARgSAxAlQAzAmgDAuQgJAhgUAmQgmBNgxAbQgJADgOAAIgTgBg");
	this.shape_43.setTransform(278.3,166.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#88CE02").s().p("AuCDDQBxh6C2hvQF8jqHziWQBPgXFMhbQD4hDCbg2QAKAsAHBFQALBbAJA7Qi3BHjlBJIm5CJQnQCRmJDdQlsDOizDHQAnkDC9jMg");
	this.shape_44.setTransform(117.8,117.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#88CE02").s().p("AC1MBQiLiHjzAGQj/AGh7hpQhzhhgUjUQgakDhuhuQiKiLjzCNQBEiBEJiTQCuhhDLhNQDKhODyhNQCFgrDmhGQC4g7BmgsQCCg5BOhDQBIgaByBWQBzBXBMCLQBVCcgLCTQgMCtiUB4QiUB3gTARQhpBfhSB2QjfFEh+JlQhcjjhfhcg");
	this.shape_45.setTransform(148.8,159.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("ACoGuQiBgPgcAAQh0ADhEgCQh8gEghgXQgmgbgCgyIAFgtQAZhEAIggQAUhKgIg1QgIg3gOgvQgLgigahAQgYg8gKhkQgLhoAVgHQARgGAIADIAgALQBLAVBSgBQBjgBBhgRQAegGAIAFQAOAJgHArQgFAfgTBfQgSBbgBA4QgEC+AIAZQAEALAcASIA0AgQBLA2BaAlIB2AvQAyAagQAlQgQAmhNAOQgWAEghAAQgpAAg5gGg");
	this.shape_46.setTransform(260.7,304.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AiuDIQgMgNgKg+IgHg7QgJg5AGhZQAHhZAMgTQATgZA2gPQAygOBAAAQCUgBApA7QAcArgKCGIgKBvQgJBQgBAUQAAALgwALQgwAMg9AEQgbABgWAAQh3AAgkgrg");
	this.shape_47.setTransform(230.9,24.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AiCGwQg1gRgdgbQgYgWgCgqQgDgrAXgqIAagsQAPgXAGgbQAHgkATghQAGgLADgVQACgXABhIIACi/QACh/AGgxQAHgzCyAnQBZAUBYAdIgsBuIg+CVQgOAggEBAQgCAXAAAxQAAAQgFAWQgFAXgEACQgCAAAIAgQAJAjgHASQgFASALAuIAOA3QANBQgTAWQgSAThYALQgWADgXAAQgzAAgxgQg");
	this.shape_48.setTransform(184.4,311.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("As3J9QgMgFgDgdQgHhEAqh7QAkhxBUh3QBfiJCHhvQBKg9CmhfQB3hECVhNQA5geDUhOQEchpDhg2QARgEgZAfQgiAqgFAPQghBgoeFzQkNC4kJCmIgiATQhLAjigB+QibB5gqA0QgRATgMAAIgFAAg");
	this.shape_49.setTransform(84,127.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.instance_5},{t:this.instance_4},{t:this.shape_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(0,0,307.1,355.9), null);


(lib.cta_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_15 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(15).call(this.frame_15).wait(1));

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AK4BqQgMgDgKgEQgJgFgGgEQgEgEAAgFQgBgHAIgKQAGgJAFAAIAIACQAJAGAKACQAIADAKAAQAOAAAGgFQAIgGAAgLQAAgKgJgGQgKgHgMgEIgZgMQgNgGgJgNQgJgOAAgTQAAgVAKgOQAUgaApAAQAMgBAJACIARAFQAIADAEAEQAEADAAAEQAAAHgGAKQgFAKgGAAIgFgCQgMgGgPAAQgRAAgGAGQgGAFAAAIQAAAIAJAHQAJAGANAEIAZAMQAHADAFAFQAFAEAFAHQAFAHACAHQACAJAAAJQAAATgGANQgGANgKAIQgUAPgdAAQgOAAgMgCgAISBlQgTgHgMgNQgYgaAAg3QAAhqBkAAQAPAAAcAGQAWAGgBAIQABAHgIALQgGALgGAAIgHgDQgQgHgWAAQgaAAgNARQgNARgBAhQAABEA0AAQAMAAALgCIAAgmIgbAAQgEAAgCgEQgDgEAAgHIAAgKQABgNAIAAIA9AAQAHAAACADQADACABAGIAABTQAAAHgIAFQgIAFgLACQgXAEgUABQgZgBgTgGgAh6BQQgMgOgHgUQgGgUAAgaQAAgZAGgUQAHgUAMgOQANgOARgGQASgIAXABQAYgBASAIQAQAGAMAOQAZAcAAAzQAAA0gZAcQgXAcgvAAQguAAgZgcgAhXgyQgHAJgDANQgCANAAAPQAAARACAMQADANAHAIQANASAXAAQAYAAAMgSQAHgIADgNQADgMAAgRQAAgPgDgNQgDgNgHgJQgMgRgYAAQgXAAgNARgAuKBQQgMgOgHgUQgGgUAAgaQAAgZAGgUQAHgUAMgOQANgOARgGQASgIAXABQAXgBATAIQARAGAMAOQAaAcAAAzQAAA0gaAcQgYAcgvAAQguAAgZgcgAtngyQgHAJgDANQgCANAAAPQAAARACAMQADANAHAIQAMASAYAAQAYAAAMgSQAHgIADgNQADgMAAgRQAAgPgDgNQgDgNgHgJQgMgRgYAAQgYAAgMARgAPeBqQgJAAgEgDQgFgCAAgFIAAi8QAAgGADgDQADgDAGAAIA/AAQARAAAPAFQANADAJAJQAHAIAGALQAEANAAAQQABASgGAMQgGALgIAHQgIAHgKADQgQAIgPAAIggAAIAABFQABAFgFACQgEADgKAAgAP6gMIAbAAQALAAAHgGQAIgFAAgQQAAgHgBgFQgDgFgEgDQgHgGgLABIgbAAgAOqBqQgOgBgCgFIgMglIhHAAIgMAlQgCAFgMABIgMAAQgSAAAAgHIABgGIBCi/QACgHAPAAIAQAAQAOAAADAHIBCC/IABAGQAAAHgPAAgAOBAXIgWhIIgBAAIgWBIIAtAAgADGBqQgPgBgCgFIgLglIhHAAIgMAlQgCAFgMABIgMAAQgSAAAAgHIABgGIBBi/QADgHAOAAIARAAQAOAAADAHIBBC/IABAGQABAHgPAAgACcAXIgVhIIgBAAIgXBIIAtAAgAlFBqQgPgBgFgHIhQh7IAAB5QAAAFgFACQgFADgIAAIgJAAQgKAAgEgDQgFgCABgFIAAi/QgBgKATAAIAMAAQAPAAAFAIIBPB5IAAh3QABgKARAAIAJAAQASAAAAAKIAAC/QAAAFgEACQgFADgJAAgAozBqQgPgBgBgFIgeh8IgeB8QgCAFgPABIgVAAQgQgBgBgFIgvjBIAAgEQgBgEAFgCQAEgCAKAAIAHAAQAJAAAGACQAEADACAEIAfCMQACgNAJgeIAYhjQACgHAPAAIALAAQAPAAACAHIAiCQIAiiOQABgEAEgDQAGgCAJAAIADAAQASAAAAAIIgxDFQgCAFgOABgADzBpQgMAAABgMIAAi5QAAgGACgDQAEgDAFAAIBEAAQAvAAAYAbQAZAcAAAxQAAAzgZAbQgMANgSAIQgSAGgXAAgAEWBBIAhAAQAMAAAJgDQAJgFAGgIQAMgRAAggQAAgfgMgRQgMgQgYAAIghAAgAkCBpQgMAAAAgMIAAi8QAAgKASAAIAKAAQASAAAAAKIAACgIBDAAQAKABAAAPIAAAJQAAAHgDAEQgCAEgFAAgAxSBpQgMAAABgMIAAi5QAAgGACgDQAEgDAFAAIBEAAQAvAAAYAbQAZAcAAAxQAAAzgZAbQgMANgSAIQgSAGgXAAgAwvBBIAhAAQAMAAAJgDQAJgFAGgIQANgRAAggQAAgfgNgRQgMgQgYAAIghAAg");
	this.shape.setTransform(163,37.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(16));

	// text shadow
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#32610E").s().p("AK4BpQgMgCgKgFQgKgEgEgEQgGgFABgEQgBgHAIgKQAGgKAFAAIAIAEQAJAFAKADQAIACAKAAQAOAAAGgGQAIgFgBgLQABgJgKgHQgJgGgMgGIgZgLQgNgHgJgMQgJgNAAgVQAAgUALgPQATgaApAAQAMAAAJACIASAFQAHAEAEADQAEAEAAAEQAAAGgGAKQgFAKgFAAIgGgDQgMgFgPAAQgQAAgHAFQgGAGAAAIQAAAIAJAGQAJAHANAFIAZALQAGADAGAFQAGAEAEAGQAEAIACAIQADAIAAAJQAAATgGANQgGAOgKAHQgTAOgdAAQgPAAgMgCgAISBlQgTgGgMgOQgYgaAAg3QAAhrBkAAQAPAAAcAHQAVAGAAAJQAAAGgGALQgIALgFAAIgHgCQgQgIgXAAQgZAAgNARQgOARAAAhQAABEAzAAQAMAAAMgCIAAgmIgaAAQgFAAgCgEQgCgDAAgIIAAgJQAAgOAJAAIA8AAQAHAAACACQAEAEAAAEIAABUQAAAHgIAFQgHAFgMACQgWAFgWgBQgZAAgSgGgAh6BPQgNgOgFgTQgHgUAAgaQAAgZAHgUQAFgUANgOQAMgNASgIQASgGAYgBQAWABASAGQARAIAMANQAZAcAAAzQAAA0gZAbQgXAcguAAQgvAAgZgcgAhXgxQgGAIgEAMQgDAOAAAPQAAARADANQAEAMAGAJQANARAYAAQAXAAANgRQAGgJADgMQADgNAAgRQAAgPgDgOQgDgMgGgIQgNgSgXAAQgYAAgNASgAuKBPQgMgOgHgTQgGgUAAgaQAAgZAGgUQAHgUAMgOQANgNARgIQASgGAXgBQAYABARAGQASAIAMANQAZAcAAAzQAAA0gZAbQgYAcgvAAQguAAgZgcgAtngxQgGAIgEAMQgDAOAAAPQAAARADANQAEAMAGAJQANARAXAAQAYAAAMgRQAHgJADgMQADgNAAgRQAAgPgDgOQgDgMgHgIQgMgSgYAAQgXAAgNASgAPeBpQgJAAgEgCQgFgCAAgFIAAi8QAAgGADgDQADgDAGAAIA/AAQARAAAOAEQAOAEAKAKQAHAGAEANQAFAMABARQAAAQgGAMQgGAMgIAHQgIAGgKAEQgQAIgPgBIggAAIAABGQABAFgFACQgEACgKAAgAP6gMIAbAAQALAAAHgGQAIgGAAgOQAAgIgCgEQgBgGgFgDQgHgFgLgBIgbAAgAOrBpQgPABgCgHIgMglIhHAAIgMAlQgCAHgLgBIgNAAQgSAAAAgGIABgFIBCjBQACgFAPAAIAQAAQAPAAACAFIBCDBIABAFQAAAGgPAAgANUAXIAtAAIgVhHIgCAAgADGBpQgOABgDgHIgMglIhHAAIgLAlQgCAHgMgBIgMAAQgTAAABgGIAAgFIBCjBQADgFAOAAIAQAAQAPAAADAFIBBDBIABAFQAAAGgOAAgABwAXIAtAAIgWhHIgBAAgAlGBpQgOABgFgJIhQh6IAAB5QgBAFgEACQgEACgJAAIgJAAQgKAAgEgCQgEgCAAgFIAAi/QAAgKASABIAMAAQAPAAAGAHIBOB5IAAh3QAAgKASABIAJAAQASgBAAAKIAAC/QAAAFgEACQgFACgJAAgAoyBpQgQABgBgHIgdh7IgfB7QgCAHgPgBIgVAAQgPABgCgHIgvi/IAAgFQgBgDAFgCQAFgCAJAAIAIAAQAIAAAGACQAEACACAFIAfCKQADgLAIggIAYhjQACgFAPAAIALAAQAQAAABAFIAiCQIAiiMQABgFAEgCQAFgCAJAAIAEAAQASAAAAAHIgxDEQgCAHgPgBgADzBpQgMAAAAgMIAAi5QAAgGADgDQAEgDAFAAIBEAAQAuAAAZAbQAZAbAAAyQAAAzgZAbQgMAOgSAGQgSAHgXAAgAEWBCIAhAAQAMgBAJgEQAJgEAGgIQAMgRAAggQAAgfgMgRQgMgRgYAAIghAAgAkCBpQgMAAAAgMIAAi8QAAgKASABIAKAAQATgBgBAKIAAChIBDAAQAKAAAAAOIAAAKQgBAHgCAEQgCAEgFAAgAxSBpQgMAAABgMIAAi5QAAgGACgDQAEgDAFAAIBEAAQAuAAAZAbQAZAbAAAyQAAAzgZAbQgMAOgSAGQgSAHgXAAgAwvBCIAhAAQAMgBAJgEQAJgEAGgIQAMgRAAggQAAgfgMgRQgMgRgYAAIghAAg");
	this.shape_1.setTransform(164.1,39.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(16));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A30GQQhkAAAAhkIAApXQAAhkBkAAMAvpAAAQBkAAAABkIAAJXQAABkhkAAg");
	mask.setTransform(162.5,40);

	// shine
	this.instance = new lib.ctashinecontainer();
	this.instance.parent = this;
	this.instance.setTransform(-68.3,39.2,2.068,2.068,0,0,0,32.8,42.6);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({x:163.2},7,cjs.Ease.get(-1)).to({x:393.9},7,cjs.Ease.get(1)).wait(1));

	// btn
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#4E9916").ss(2,1,1).p("A30mPMAvpAAAQBkAAAABkIAAJXQAABkhkAAMgvpAAAQhkAAAAhkIAApXQAAhkBkAAg");
	this.shape_2.setTransform(162.5,40);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#4E9916","#59A91B"],[0,1],1.8,34.6,1.8,-25.7).s().p("A30GQQhkAAAAhkIAApXQAAhkBkAAMAvpAAAQBkAAAABkIAAJXQAABkhkAAg");
	this.shape_3.setTransform(162.5,40);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#5FB41C","#68BD25"],[0,1],1.8,34.6,1.8,-25.7).s().p("A30GQQhkAAAAhkIAApXQAAhkBkAAMAvpAAAQBkAAAABkIAAJXQAABkhkAAg");
	this.shape_4.setTransform(162.5,40);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[{t:this.shape_4},{t:this.shape_2}]},1).wait(15));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,327,82);


// stage content:
(lib.GSAP_AdStarter_Demo_2017 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//set scope activation object 
		var root = this,
			tl;
		//assign clickthrough url
		clickTag = "http://www.greensock.com";
		
		//prevent children of mc from dispatching mouse events 
		root.cta_mc.mouseChildren = false;
		root.cta_mc.on("mouseover", function(){this.gotoAndPlay(1);});
		root.cta_mc.on("mouseout", function(){this.gotoAndStop(0);});
		root.logo_mc.on("mouseover", function(){
				TweenMax.to(this, 1.25, {scaleX:.53, scaleY:.53, ease:Elastic.easeOut});
			});
		root.logo_mc.on("mouseout", function(){
			    //if the ad is asleep, wake the ad to allow animation to complete
			    ad.wake(1500);
				TweenMax.to(this, 1.25, {scaleX:.5, scaleY:.5, ease:Elastic.easeOut});
			});
		
		//gsap timeline
		tl = new TimelineMax();
		tl.from(root.headline_mc, 1, {y:"250", ease:Back.easeOut});
		tl.from(root.tagline_mc, .5, {y:"255", ease:Back.easeOut}, "-=.5");
		tl.from(root.logo_mc, .75, {scaleX:0, scaleY:0, alpha:0, ease:Back.easeOut}, "-=.25");
		tl.to(root.cta_mc, .75, {scaleX:.40, scaleY:.40, repeat:-1, yoyo:true, repeatDelay:0.25, ease:Expo.easeInOut});
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo
	this.logo_mc = new lib.logo_mc();
	this.logo_mc.parent = this;
	this.logo_mc.setTransform(161.8,192.5,0.5,0.5,0,0,0,219.5,350.9);
	this.logo_mc.cache(-2,-2,311,360);

	this.timeline.addTween(cjs.Tween.get(this.logo_mc).wait(1));

	// cta
	this.cta_mc = new lib.cta_mc();
	this.cta_mc.parent = this;
	this.cta_mc.setTransform(212.3,222.5,0.45,0.45,0,0,0,153.9,37.8);

	this.timeline.addTween(cjs.Tween.get(this.cta_mc).wait(1));

	// text
	this.headline_mc = new lib.headline_mc();
	this.headline_mc.parent = this;
	this.headline_mc.setTransform(71.4,215.7,0.5,0.5,0,0,0,121.3,20.5);
	this.headline_mc.cache(-2,-2,247,45);

	this.tagline_mc = new lib.tagline_mc();
	this.tagline_mc.parent = this;
	this.tagline_mc.setTransform(58.5,236.7,0.5,0.5,0,0,0,95.4,9.8);
	this.tagline_mc.cache(-2,-2,195,24);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.tagline_mc},{t:this.headline_mc}]}).wait(1));

	// grad_02
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],1.3,-66.5,1.3,-136.3).s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,268);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// grad_01
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#262626","#000000"],[0,1],-59.7,71.6,143,71.6).s().p("A3bIXIAAwtMAu3AAAIAAQtg");
	this.shape_1.setTransform(150,196.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// bg
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#666666","#000000"],[0,1],3.2,-245,3.2,21.6).s().p("Egu3AnEMAAAhOHMBdvAAAMAAABOHg");
	this.shape_2.setTransform(150,125,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,125,300,393);
// library properties:
lib.properties = {
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;