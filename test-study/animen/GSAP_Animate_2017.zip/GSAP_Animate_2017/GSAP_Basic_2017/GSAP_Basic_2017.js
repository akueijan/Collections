(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.subtitle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BFBBBB").s().p("AgdApQgJgKAAgOIAPAAQAAAIAEAEQAGAIAOgBQAJABAHgEQAHgEAAgIQAAgGgGgDQgDgCgLgDIgLgDQgNgDgFgDQgLgGAAgLQAAgNAKgJQAKgIAQAAQAVAAAJAMQAGAJAAAIIgPAAQAAgFgEgEQgFgGgNgBQgJABgFADQgFADAAAGQAAAGAHAEQADACAHABIAKADQARAFAGACQAJAGAAANQAAANgJAJQgKAJgUAAQgUAAgJgJg");
	this.shape.setTransform(182.9,1.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BFBBBB").s().p("AgKBUIgFgBIAAgOQALAAADgBQABgCAAgIIAAhpIAQAAIAABqQAAALgEAFQgGAJgOAAgAAAhBIAAgSIAQAAIAAASg");
	this.shape_1.setTransform(177.2,1.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BFBBBB").s().p("AgIAJIAAgSIARAAIAAASg");
	this.shape_2.setTransform(174.9,4.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BFBBBB").s().p("AAWAwIAAg7QAAgIgCgFQgEgJgMAAIgIABQgGACgFAGQgEAFgCAFIgBANIAAAxIgQAAIAAhdIAPAAIAAANQAIgIAHgDQAIgEAIAAQATAAAIAOQADAHABAOIAAA8g");
	this.shape_3.setTransform(169,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BFBBBB").s().p("AgHBAIAAhcIAPAAIAABcgAgHguIAAgSIAPAAIAAASg");
	this.shape_4.setTransform(163.5,-0.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BFBBBB").s().p("AAvAwIAAhAQAAgKgFgEQgEgDgIAAQgIAAgIAHQgGAFAAAPIAAA2IgPAAIAAg9QAAgJgCgEQgEgHgKAAQgJAAgHAHQgIAHABASIAAAxIgQAAIAAhdIAPAAIAAANIALgKQAHgFAKAAQALAAAIAGQACACADAHQAGgIAHgDQAHgEAJAAQATAAAGAOQAFAHAAAMIAAA+g");
	this.shape_5.setTransform(155.6,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BFBBBB").s().p("AgIAJIAAgSIARAAIAAASg");
	this.shape_6.setTransform(147,4.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BFBBBB").s().p("AAXAvIgXgjIgWAjIgUAAIAhgvIggguIAVAAIAUAhIAWghIAUABIggAtIAhAvg");
	this.shape_7.setTransform(141.5,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BFBBBB").s().p("AgjAqQgJgIAAgMQAAgNAJgHQAIgGANgCIAYgDQAGgBACgEIABgGQAAgIgGgEQgFgDgKAAQgMAAgGAGQgDAEgBAHIgOAAQAAgRALgHQALgHAOAAQAPAAALAHQALAGAAANIAAA2IABAEQAAAAAAAAQAAABABAAQAAAAABAAQABAAAAAAIADAAIACAAIAAALIgFACIgFAAQgIAAgEgGQgCgDgBgGQgFAHgIAEQgJAFgLAAQgNAAgIgIgAALACIgJACIgJABQgIABgEADQgIAEAAAJQAAAHAFAEQAFADAHAAQAIAAAIgDQANgHgBgOIAAgMIgHACg");
	this.shape_8.setTransform(133.7,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#BFBBBB").s().p("AAtBAIAAhLIAAgNIABgUIglBsIgRAAIglhsIAAAFIAAAOIABAOIAABLIgRAAIAAiAIAZAAIAkBsIAlhsIAZAAIAACAg");
	this.shape_9.setTransform(122.6,-0.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BFBBBB").s().p("AAWAwIAAg7QAAgIgCgFQgFgJgLAAIgIABQgGACgFAGQgEAFgCAFIgBANIAAAxIgQAAIAAhdIAQAAIAAANQAGgIAIgDQAIgEAHAAQAVAAAGAOQAFAHAAAOIAAA8g");
	this.shape_10.setTransform(111.6,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BFBBBB").s().p("AgdAlQgNgNAAgXQAAgWANgOQAMgOATAAQAKAAAJAFQAJAEAFAIQAFAHACAJIABAUIhEAAQABAPAGAIQAGAJANAAQAMAAAHgIQAEgFACgGIAQAAIgEALQgEAHgEAEQgHAHgLACQgGACgGAAQgRAAgMgNgAAbgHQgBgLgEgGQgGgLgPAAQgKAAgHAIQgIAIAAAMIAzAAIAAAAg");
	this.shape_11.setTransform(103,1.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BFBBBB").s().p("AgdAlQgNgNAAgXQAAgWANgOQAMgOATAAQAKAAAJAFQAJAEAFAIQAFAHACAJIABAUIhEAAQABAPAGAIQAGAJANAAQAMAAAHgIQAEgFACgGIAQAAIgEALQgEAHgEAEQgHAHgLACQgGACgGAAQgRAAgMgNgAAbgHQgBgLgEgGQgGgLgPAAQgKAAgHAIQgIAIAAAMIAzAAIAAAAg");
	this.shape_12.setTransform(94.5,1.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BFBBBB").s().p("AATAvIgThIIgRBIIgRAAIgchdIASAAIASBJIAShJIARAAIASBJIAUhJIAQAAIgbBdg");
	this.shape_13.setTransform(84.6,1.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BFBBBB").s().p("AgIBAIAAhwIgrAAIAAgQIBnAAIAAAQIgrAAIAABwg");
	this.shape_14.setTransform(74.2,-0.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BFBBBB").s().p("AgdA1QgMgNABgWQgBgTALgQQAKgPAUAAQAJAAAIAFQAEADAFAGIAAgvIAQAAIAACAIgPAAIAAgNQgFAJgHAEQgIADgJAAQgQAAgLgNgAgRgJQgHAJAAARQAAAPAGALQAHAJANABQALAAAHgKQAHgJAAgSQAAgRgIgIQgGgJgLAAQgLAAgIAJg");
	this.shape_15.setTransform(61.4,-0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BFBBBB").s().p("AgjAqQgJgIAAgMQAAgNAJgHQAIgGAOgCIAXgDQAGgBACgEIABgGQAAgIgGgEQgFgDgKAAQgMAAgGAGQgCAEgBAHIgPAAQAAgRALgHQALgHAOAAQAQAAAKAHQAKAGAAANIAAA2IABAEQABAAAAAAQAAABABAAQAAAAABAAQABAAABAAIACAAIACAAIAAALIgFACIgFAAQgJAAgDgGQgCgDgBgGQgEAHgJAEQgJAFgKAAQgOAAgIgIgAALACIgJACIgJABQgIABgFADQgHAEAAAJQAAAHAFAEQAGADAGAAQAIAAAIgDQAMgHAAgOIAAgMIgHACg");
	this.shape_16.setTransform(53.4,1.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BFBBBB").s().p("AgfAlQgMgNAAgWQAAgXAMgOQAMgOATAAQATAAAMAMQANAMAAAYQAAAVgLAPQgLAPgXAAQgTAAgLgNgAgUgYQgGALAAAOQAAAPAGAKQAHAKANAAQAPAAAGgLQAGgMAAgOQAAgNgEgIQgHgNgQAAQgNAAgHALg");
	this.shape_17.setTransform(44.6,1.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#BFBBBB").s().p("AgHBAIAAiAIAPAAIAACAg");
	this.shape_18.setTransform(39.3,-0.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BFBBBB").s().p("AgfAlQgMgNAAgWQAAgXAMgOQAMgOATAAQATAAAMAMQANAMAAAYQAAAVgLAPQgLAPgXAAQgTAAgLgNgAgUgYQgGALAAAOQAAAPAGAKQAHAKANAAQAPAAAGgLQAGgMAAgOQAAgNgEgIQgHgNgQAAQgNAAgHALg");
	this.shape_19.setTransform(30.1,1.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BFBBBB").s().p("AgFA4QgDgGAAgKIAAg9IgNAAIAAgNIANAAIAAgaIAPAAIAAAaIAPAAIAAANIgPAAIAAA8QAAAGADACIAHAAIACAAIADAAIAAAMIgGACIgGAAQgKAAgFgFg");
	this.shape_20.setTransform(24.2,-0.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BFBBBB").s().p("AgdAlQgNgNAAgXQAAgWANgOQAMgOATAAQAKAAAJAFQAJAEAFAIQAFAHACAJIABAUIhEAAQABAPAGAIQAGAJANAAQAMAAAHgIQAEgFACgGIAQAAIgEALQgEAHgEAEQgHAHgLACQgGACgGAAQgRAAgMgNgAAbgHQgBgLgEgGQgGgLgPAAQgKAAgHAIQgIAIAAAMIAzAAIAAAAg");
	this.shape_21.setTransform(14.6,1.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BFBBBB").s().p("AgFA4QgDgGAAgKIAAg9IgNAAIAAgNIANAAIAAgaIAPAAIAAAaIAPAAIAAANIgPAAIAAA8QAAAGADACIAGAAIADAAIADAAIAAAMIgGACIgGAAQgLAAgEgFg");
	this.shape_22.setTransform(8.7,-0.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BFBBBB").s().p("AgjAqQgIgIAAgMQAAgNAIgHQAIgGANgCIAZgDQAFgBACgEIABgGQAAgIgGgEQgGgDgJAAQgNAAgFAGQgCAEgCAHIgPAAQABgRALgHQALgHAOAAQAPAAALAHQALAGAAANIAAA2IABAEQAAAAAAAAQABABAAAAQABAAAAAAQABAAAAAAIADAAIADAAIAAALIgGACIgFAAQgJAAgDgGQgCgDAAgGQgFAHgKAEQgHAFgMAAQgMAAgJgIgAALACIgJACIgIABQgJABgFADQgHAEAAAJQAAAHAFAEQAGADAGAAQAJAAAGgDQANgHABgOIAAgMIgIACg");
	this.shape_23.setTransform(2.9,1.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BFBBBB").s().p("AgHBAIAAiAIAPAAIAACAg");
	this.shape_24.setTransform(-2.7,-0.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#BFBBBB").s().p("AgpBDIAAiCIAQAAIAAAMQAFgGAFgEQAIgFAKAAQAQAAALAMQAMAMgBAXQABAegRAOQgKAHgNABQgKgBgHgEQgFgDgFgGIAAAwgAgXgkQgCAJAAAOQAAAKACAIQAHAOAQAAQAKAAAIgKQAHgIAAgSQAAgLgDgJQgGgPgQAAQgQAAgHAQg");
	this.shape_25.setTransform(-8,2.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#BFBBBB").s().p("AAvAwIAAhAQAAgKgFgEQgEgDgIAAQgJAAgHAHQgGAFAAAPIAAA2IgPAAIAAg9QAAgJgCgEQgEgHgKAAQgJAAgHAHQgIAHAAASIAAAxIgPAAIAAhdIAPAAIAAANIALgKQAHgFAKAAQALAAAIAGQACACADAHQAGgIAHgDQAHgEAIAAQAUAAAGAOQAFAHAAAMIAAA+g");
	this.shape_26.setTransform(-19.1,1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#BFBBBB").s().p("AgdAlQgNgNAAgXQAAgWANgOQAMgOATAAQAKAAAJAFQAJAEAFAIQAFAHACAJIABAUIhEAAQABAPAGAIQAGAJANAAQAMAAAHgIQAEgFACgGIAQAAIgEALQgEAHgEAEQgHAHgLACQgGACgGAAQgRAAgMgNgAAbgHQgBgLgEgGQgGgLgPAAQgKAAgHAIQgIAIAAAMIAzAAIAAAAg");
	this.shape_27.setTransform(-30.3,1.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#BFBBBB").s().p("AgFA4QgDgGAAgKIAAg9IgNAAIAAgNIANAAIAAgaIAPAAIAAAaIAPAAIAAANIgPAAIAAA8QAAAGADACIAHAAIACAAIADAAIAAAMIgGACIgGAAQgLAAgEgFg");
	this.shape_28.setTransform(-36.2,-0.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#BFBBBB").s().p("AAvAwIAAhAQAAgKgFgEQgEgDgIAAQgIAAgHAHQgHAFAAAPIAAA2IgPAAIAAg9QAAgJgCgEQgEgHgKAAQgJAAgHAHQgHAHAAASIAAAxIgRAAIAAhdIAQAAIAAANIALgKQAHgFAKAAQALAAAIAGQACACAEAHQAEgIAHgDQAIgEAJAAQASAAAIAOQADAHAAAMIAAA+g");
	this.shape_29.setTransform(-48.1,1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#BFBBBB").s().p("AgfAlQgMgNAAgWQAAgXAMgOQAMgOATAAQATAAAMAMQANAMAAAYQAAAVgLAPQgLAPgXAAQgTAAgLgNgAgUgYQgGALAAAOQAAAPAGAKQAHAKANAAQAPAAAGgLQAGgMAAgOQAAgNgEgIQgHgNgQAAQgNAAgHALg");
	this.shape_30.setTransform(-59.2,1.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#BFBBBB").s().p("AgFA4QgDgGAAgKIAAg9IgNAAIAAgNIANAAIAAgaIAPAAIAAAaIAPAAIAAANIgPAAIAAA8QAAAGADACIAHAAIABAAIAEAAIAAAMIgGACIgGAAQgKAAgFgFg");
	this.shape_31.setTransform(-65.2,-0.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#BFBBBB").s().p("AgdApQgJgKAAgOIAPAAQAAAIAEAEQAGAIAOgBQAJABAHgEQAHgEAAgIQAAgGgGgDQgDgCgLgDIgLgDQgNgDgFgDQgLgGAAgLQAAgNAKgJQAKgIAQAAQAVAAAJAMQAGAJAAAIIgPAAQAAgFgEgEQgFgGgNgBQgJABgFADQgFADAAAGQAAAGAHAEQADACAHABIAKADQARAFAGACQAJAGAAANQAAANgJAJQgKAJgUAAQgUAAgJgJg");
	this.shape_32.setTransform(-70.6,1.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#BFBBBB").s().p("AghAjQgDgHAAgMIAAg/IAQAAIAAA9QAAAHACAFQAEAIALAAQAPAAAGgOQADgIAAgNIAAguIAQAAIAABdIgPAAIAAgOQgDAFgEAEQgJAHgMAAQgTAAgIgNg");
	this.shape_33.setTransform(-78.7,1.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#BFBBBB").s().p("AgcAlQgMgOAAgUQAAgYANgOQAMgOARAAQAQAAAKAIQALAIABATIgPAAQgCgJgEgGQgFgFgMAAQgNAAgHAOQgEAKgBANQAAAOAHAKQAFAJAMAAQAKAAAGgGQAGgGACgKIAPAAQgDATgKAIQgKAJgRAAQgSAAgKgNg");
	this.shape_34.setTransform(-86.5,1.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#BFBBBB").s().p("AgjAqQgJgIAAgMQAAgNAJgHQAIgGAOgCIAXgDQAGgBACgEIABgGQAAgIgGgEQgFgDgKAAQgMAAgGAGQgCAEgCAHIgOAAQAAgRALgHQALgHAOAAQAQAAAKAHQAKAGAAANIAAA2IABAEQABAAAAAAQAAABABAAQAAAAABAAQABAAABAAIACAAIACAAIAAALIgFACIgFAAQgJAAgDgGQgCgDgBgGQgFAHgIAEQgJAFgKAAQgOAAgIgIgAALACIgJACIgJABQgIABgEADQgIAEAAAJQAAAHAFAEQAGADAGAAQAIAAAIgDQANgHgBgOIAAgMIgHACg");
	this.shape_35.setTransform(-97.9,1.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#BFBBBB").s().p("AgdApQgJgKAAgOIAPAAQAAAIAEAEQAGAIAOgBQAJABAHgEQAHgEAAgIQAAgGgGgDQgDgCgLgDIgLgDQgNgDgFgDQgLgGAAgLQAAgNAKgJQAKgIAQAAQAVAAAJAMQAGAJAAAIIgPAAQAAgFgEgEQgFgGgNgBQgJABgFADQgFADAAAGQAAAGAHAEQADACAHABIAKADQARAFAGACQAJAGAAANQAAANgJAJQgKAJgUAAQgUAAgJgJg");
	this.shape_36.setTransform(-109.6,1.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#BFBBBB").s().p("AgdAlQgNgNAAgXQAAgWANgOQAMgOATAAQAKAAAJAFQAJAEAFAIQAFAHACAJIABAUIhEAAQABAPAGAIQAGAJANAAQAMAAAHgIQAEgFACgGIAQAAIgEALQgEAHgEAEQgHAHgLACQgGACgGAAQgRAAgMgNgAAbgHQgBgLgEgGQgGgLgPAAQgKAAgHAIQgIAIAAAMIAzAAIAAAAg");
	this.shape_37.setTransform(-117.7,1.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#BFBBBB").s().p("AgdApQgJgKAAgOIAPAAQAAAIAEAEQAGAIAOgBQAJABAHgEQAHgEAAgIQAAgGgGgDQgDgCgLgDIgLgDQgNgDgFgDQgLgGAAgLQAAgNAKgJQAKgIAQAAQAVAAAJAMQAGAJAAAIIgPAAQAAgFgEgEQgFgGgNgBQgJABgFADQgFADAAAGQAAAGAHAEQADACAHABIAKADQARAFAGACQAJAGAAANQAAANgJAJQgKAJgUAAQgUAAgJgJg");
	this.shape_38.setTransform(-125.6,1.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#BFBBBB").s().p("AghAjQgDgHAAgMIAAg/IAQAAIAAA9QAAAHACAFQAEAIALAAQAPAAAGgOQADgIAAgNIAAguIAQAAIAABdIgPAAIAAgOQgDAFgEAEQgJAHgMAAQgTAAgIgNg");
	this.shape_39.setTransform(-133.7,1.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#BFBBBB").s().p("AgjAqQgJgIAAgMQAAgNAJgHQAIgGAOgCIAYgDQAFgBACgEIABgGQAAgIgGgEQgGgDgJAAQgMAAgGAGQgDAEAAAHIgQAAQABgRALgHQALgHAOAAQAQAAAKAHQAKAGAAANIAAA2IABAEQABAAAAAAQAAABABAAQABAAAAAAQABAAABAAIACAAIACAAIAAALIgFACIgFAAQgIAAgEgGQgCgDAAgGQgGAHgJAEQgIAFgKAAQgNAAgJgIgAALACIgJACIgIABQgJABgFADQgHAEAAAJQAAAHAFAEQAGADAGAAQAIAAAHgDQANgHAAgOIAAgMIgHACg");
	this.shape_40.setTransform(-145.4,1.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#BFBBBB").s().p("AgHBAIAAiAIAPAAIAACAg");
	this.shape_41.setTransform(-151,-0.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#BFBBBB").s().p("AgIBBIAAhQIgNAAIAAgMIANAAIAAgPQAAgKADgEQAFgJAQABIADAAIADAAIAAAPIgDgBIgCAAQgIAAgBAEQgCADAAAQIAQAAIAAAMIgQAAIAABQg");
	this.shape_42.setTransform(-154.1,-0.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#BFBBBB").s().p("AgdApQgJgKAAgOIAPAAQAAAIAEAEQAGAIAOgBQAJABAHgEQAHgEAAgIQAAgGgGgDQgDgCgLgDIgLgDQgNgDgFgDQgLgGAAgLQAAgNAKgJQAKgIAQAAQAVAAAJAMQAGAJAAAIIgPAAQAAgFgEgEQgFgGgNgBQgJABgFADQgFADAAAGQAAAGAHAEQADACAHABIAKADQARAFAGACQAJAGAAANQAAANgJAJQgKAJgUAAQgUAAgJgJg");
	this.shape_43.setTransform(-163,1.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#BFBBBB").s().p("AgHBAIAAhcIAPAAIAABcgAgHguIAAgSIAPAAIAAASg");
	this.shape_44.setTransform(-168,-0.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#BFBBBB").s().p("AAWBBIAAg8QAAgJgCgFQgFgIgMAAQgJAAgIAHQgHAHgBASIAAAyIgQAAIAAiBIAQAAIAAAwQAGgHAEgDQAIgFAKAAQAVAAAIAPQADAHAAANIAAA9g");
	this.shape_45.setTransform(-173.5,-0.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#BFBBBB").s().p("AgIBAIAAhwIgrAAIAAgQIBnAAIAAAQIgrAAIAABwg");
	this.shape_46.setTransform(-182.4,-0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.subtitle, new cjs.Rectangle(-266,-12.8,530,24.8), null);


(lib.Path_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AALBQQgqgBgugGIgIiQIAmgIQA6AbBBACQgDARgBAWQgCAqAOAaQANAXhKAAIgMAAg");
	this.shape.setTransform(8.6,8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_21, new cjs.Rectangle(0,0,17.3,16.1), null);


(lib.Path_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhYA1QAbgIAKgXQALgZgTgYQgOgRgTgRQgHgIAXgBQAXgBBMAoQAmAUAiATIhGA/g");
	this.shape.setTransform(9.5,7.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_20, new cjs.Rectangle(0.1,0,18.9,14.3), null);


(lib.Path_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgXAsQhdgBg8gJQgdgFgMgEIAFgyQA8AWB3gDQA0gCA2gGQBAgJApgOQAlgNACARQABAIgGALIggAdQgUAIgjAHQhAAOhGAAIgOAAg");
	this.shape.setTransform(21.8,4.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,43.5,8.7), null);


(lib.Path_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUAkQhdgBgygGQgZgEgHgDIgCgyQA9AWB2gDQBOgDAXgCQA+gFAmgPQAQgFgCAQQAAAHgEAJIgKARQgUAHgjAHQhAAMhFAAIgPAAg");
	this.shape.setTransform(19.8,3.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0.1,39.5,7.2), null);


(lib.Path_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjiGyQgEgNgCgRIgGgvQgOiMgohkQguh1hNgvQB3hBD8h7QEdiLB9gyQA6gYgJAJQgrArgMAXQgRAeAAAqQAAAqgCACQh4Bqh8CDQj3EDhKDLQgDgDABgFg");
	this.shape.setTransform(41.6,44.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0.3,83.2,88.5), null);


(lib.Path_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAPCAQiChljXAHQCVgKDWiTQCrh3B1iDQALgLgCAMIgMAqQgcBYAAAuQACDEgNBkQgTCZg/B/QhSiuhkhOg");
	this.shape.setTransform(33.1,38);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_8, new cjs.Rectangle(0,0.1,66.2,75.9), null);


(lib.Path_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAkEdQgDg3gHg7QgMh2gQgUQgPgTg2gqQg/gzgKgKQgRgQAWgmQAdgwgCgaQgCgiAShFQAJgjAKgbIC4CTQgigOgXAgQgXAfAJApQAGAbA7BJQA3BXgEB1QgDBjgSBJQgJAkgJAQg");
	this.shape.setTransform(15.4,38.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0.2,0,30.5,76.6), null);


(lib.Path_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ah0F4QBwiPAGgaQAEgRgdhrIgfhoIBtluQgDBhASCjIAdDiQAIA2AKAyQADAegVAfQggAugrBOg");
	this.shape.setTransform(11.7,38.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_5, new cjs.Rectangle(0,0,23.4,77.6), null);


(lib.Path_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag0A5QgrgOgagYQgcgZgVguIAuACIATAvICcAbIB0hcQADASABAVQABApgOARQghAlhPADIgSAAQgwAAgggMg");
	this.shape.setTransform(17.1,6.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_4, new cjs.Rectangle(0,0,34.2,13.9), null);


(lib.Path = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgqBAIgYgrIBChYQAGAgALAcQAQAnAWASQALALABADQABAEgJAAg");
	this.shape.setTransform(6.7,6.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0,0,13.4,13.6), null);


(lib.greensock_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#88CE02").s().p("AriIaQhrh4AAjjQAAjhBqh3QBsh3DOAAQDNAABrB4QBpB2AADhQAADjhpB4QhqB4jOAAQjNAAhsh4gApKC/QAAEJChAAQBRAAAnhDQAnhCAAiEQAAiDgnhAQgnhChRAAQihAAAAEFgA5nJZQhogvAAgzQAAgmAng4QAog5AbAAQAJAAAYANIA2AbQBVAoBTAAQBEAAApgYQA2ggAAhHQAAhBhPguQgbgRg1gWIhbgnQhzg0g4hAQhPhXAAiKQAAiyCChfQBuhSCqAAQCDAABeAnQBWAkAAAtQAAAngfA2QgiA6geAAIg9gVQg9gWhGAAQhaAAgpAlQgeAaAAAnQAABABOAsQAvAbB8AxQB0AzA4A/QBOBXAACKQAADGh9BlQhnBUijAAQi1AAh4g3gADTIdQhrhxAAjpQgBjoBqhzQBuh4DkAAQBoAABVAeQBiAjAAA3QAAAagjA0QgkA2gUAAQgRgEgOgIQhGgnhRAAQhnAAgvBBQgtA/AACGQgBCHAsBAQAtBCBhAAQBcAABNgpQAMgGATgEQAaAAAhA1QAfAxAAAcQAAA/iDAiQhZAXhSAAQjdAAhrhygAYlKKQgqAAgXgHQgcgHgLgTIjwmNIgGACIAAF1QAAAcgZANQgZAOg2AAIgxAAQg2AAgagOQgYgNAAgcIAAytIgBAAQAAgcAYgNQAZgOA3AAIAxAAQA2AAAZAOQAZANgBAcIAAKrIAHACIDSk4QAOgUAcgHQAUgGAsAAIA/AAQBiAAAAAbQgEATgMAPIjxFVIEZG+IALAVQAEAKAAAGQAAAbhiAAg");
	this.shape.setTransform(604.6,65.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A92HUQiKiYAAkwQAApzIwAAQB7AABqAkQBlAjAAAlQAAAXgVAlQgWAogQAAQgjgTgsgTQhYglhmAAQjcAAhhB+QhYByAADuQAADgBOB3QBfCRDWAAQBBAAA/gGQA7gHAjgJIAAldIjKAAQgjAAAAgzIAAgcQAAgcAIgKQAIgMATAAIEvAAQAcAAAMANQALAKAAAbIAAHKQAABEh2AfQhgAZirAAQkFAAiGiUgAIqH0QhohwAAjoQAAjkBmh2QBmh3DFAAQCxAABaBzQBaByAADcQAAAQgVAbQgWAcgOAAIoiAAQALCQA/BDQBBBECAAAQBcAABUglQAqgSAigSQARAAAXAkQAVAhAAAQQAAAihaAkQhjAoh6AAQjYAAhohwgAJdBZIHCAAQAAkQjQAAQjfAAgTEQgAlVH0QhohwAAjoQgCjjBmh3QBnh3DGAAQCwAABaBzQBaByAADcQAAAQgVAbQgWAcgOAAIohAAQAKCQBABDQBABECAAAQBbAABUglQAqgSAjgSQARAAAXAkQAVAhAAAQQAAAihaAkQhjAoh5AAQjYAAhohwgAklBZIHCAAQAAkQjPAAQjgAAgTEQgAtwJjQhFAAAAgnIAApeIgBgBQABhvgVhqQAAgWAmgLQAcgIAbAAQAbAAAPAoQAGAOANA8QAtg/AzgiQAzghA1AAQAxAAAbATQAYASAAAeQAAAdgJAeQgLAjgOAAQgHAAgbgJQgcgJgiAAQg4AAg5A1IguA0IAAJ5QAAAnhFAAgAe2JeQhGAAAAgmIAApKQAAhQgtgrQgvgshVAAQg6AAg6AgQg7AhgrA3IAAJ4QAAAnhFAAIgGAAQhGAAAAgnIAApaIABAAQABhvgVhqQAAgWAmgLQAbgIAcAAQAbAAAPAoQAGAOANA8QA3g9BIgjQBHgiBHAAQCFAABKBKQBKBLAACCIAAJWQAAAmhFAAg");
	this.shape_1.setTransform(204.9,69.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.greensock_mc, new cjs.Rectangle(0,0,779,131.6), null);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Path();
	this.instance.parent = this;
	this.instance.setTransform(276.3,125.5,1,1,0,0,0,6.7,6.8);
	this.instance.alpha = 0.398;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AH0HgQhPhqhagoQhlgtjBgDQjLgDiGhiQiThqgYjDQgRiXgchUQgihnhCg5IAxgfQA8A6AkBoQAfBdAMB4QAUDTB0BhQB7BpD9gGQClgFBxA5QBjAxBHBmQAPAWAZAOQAXANAVAAQAAAAAAAAQABABAAAAQAAAAgBABQAAAAAAABQgCADACACIgTArQg9gNgkgyg");
	this.shape.setTransform(120.2,199.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#88CE02").s().p("AD0AsQgEgDgRgEQgOgFgHgEIgagOQgPgGgQABQgZADhVAXQgwANgzgMQhHgUgcgGQgugKg7ADIAEgyQBEAdCmAmQAmAIBVg2QAkgXAtALQApALAaAcQAcAgAAALQAAAEgGAAQgGAAgNgEg");
	this.shape_1.setTransform(239.9,64.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1.6,0,1).p("AjxgwQAjAWBSAZQA/ASAqAHQAWAFArgXQAXgLAkgVQAdgNAgADQAqAGApAkQAGAGgUAaQgOgDgRgHQgagPgdADQgbAEhRAWQguAMg0gLQhJgUgcgGQgsgKg3AD");
	this.shape_2.setTransform(239.4,63.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#88CE02").s().p("Ag1ArQhJgTgcgGQgsgKg3ACIAQg6QAjAXBSAZQA/ARAqAIQAWAFArgXQAXgLAkgVQAdgOAgAEQAqAFApAkQAGAGgUAbQgOgDgRgHQgagPgdADQgbADhRAWQgZAHgZAAQgYAAgYgGg");
	this.shape_3.setTransform(239,63.7);

	this.instance_1 = new lib.Path_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(231.1,50,1,1,0,0,0,17.1,6.9);
	this.instance_1.alpha = 0.398;

	this.instance_2 = new lib.Path_5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(235.7,226.1,1,1,0,0,0,11.7,38.8);
	this.instance_2.alpha = 0.398;

	this.instance_3 = new lib.Path_6();
	this.instance_3.parent = this;
	this.instance_3.setTransform(202,124.2,1,1,0,0,0,15.4,38.3);
	this.instance_3.alpha = 0.398;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AnKDDQDbiIF8izQC+hbCTg/IAEAKQAEALgEANQgOAnhaAdQhoAglRCwQlHCshdBDg");
	this.shape_4.setTransform(90.1,131.9);

	this.instance_4 = new lib.Path_8();
	this.instance_4.parent = this;
	this.instance_4.setTransform(161.7,220.2,1,1,0,0,0,33,38);
	this.instance_4.alpha = 0.398;

	this.instance_5 = new lib.Path_9();
	this.instance_5.parent = this;
	this.instance_5.setTransform(101.2,146.9,1,1,0,0,0,41.6,44.5);
	this.instance_5.alpha = 0.398;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EFEFEF").s().p("AgsBpQgKgFABgHQACgIgMgJQgvghgNgXQgSgfAPg0QABgKAPgOIAlgdQAvgDAnALQAsANAcAeIAhAfQASATgCANQAAAGgXAbIgPASIgPAPIgrAhQgIAIgMAIQgJAFgKAAQgTAAgYgNg");
	this.shape_5.setTransform(197.2,162.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ABGAuQgGgIgjgYQgkgXgRgHQgSgIgTgLQgSgLAAgDQAAgCAIAAIAIAAIA3AbQAxAZAVAWQAUAWgCAFQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAQgDAAgFgGg");
	this.shape_6.setTransform(266.4,71.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgsATQg2gFgfgOQgfgNAGgFQAEgDAJAAQArAYBDADQAZACA8gEIAwgFQAsgHACABQAHABABAGQgIAEgQAFQghAJgrACIguACQgbAAgbgDg");
	this.shape_7.setTransform(204.9,64.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EFEFEF").s().p("AhJCVQgygZgNgRQgPgVAIgpQAHgbApgjQAcgaA1gjIgrAJQgTAFACgQQAFggAQgQQAWgYACgEQgHgHBAADQBAADANALIAAACQAAAJAMAgQAJAagFALQgDAFgIgFQgNgJgFgBQAPBWAgBOQAbA8hLANIghABQhDAAhAgNg");
	this.shape_8.setTransform(179.3,335);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EFEFEF").s().p("AhNEWQgxgIgYgMQAEgZAPjrQAKijAnh2QB0AjB1AMQgPBfglBXQgUAwgmBTQgNAkgDBYQgEBPgCAAQgRAEgUAAQgbAAgggGg");
	this.shape_9.setTransform(189.9,288.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AhzAwQhpgcgggRIgMgJIgIhAQADAMBYApQBfArA9AMQA4AKBygFQBggFAggHIgEAdQg3AIhLADIgtABQh5AAhYgYg");
	this.shape_10.setTransform(236.2,147.9);

	this.instance_6 = new lib.Path_18();
	this.instance_6.parent = this;
	this.instance_6.setTransform(242.2,286.3,1,1,0,0,0,19.8,3.6);
	this.instance_6.alpha = 0.301;

	this.instance_7 = new lib.Path_19();
	this.instance_7.parent = this;
	this.instance_7.setTransform(243.3,275.9,1,1,0,0,0,21.8,4.4);
	this.instance_7.alpha = 0.301;

	this.instance_8 = new lib.Path_20();
	this.instance_8.parent = this;
	this.instance_8.setTransform(292.4,340.5,1,1,0,0,0,9.6,7.1);
	this.instance_8.alpha = 0.301;

	this.instance_9 = new lib.Path_21();
	this.instance_9.parent = this;
	this.instance_9.setTransform(234.3,336.3,1,1,0,0,0,8.6,8);
	this.instance_9.alpha = 0.301;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#88CE02").s().p("ADbGQQgkgDhlgPQhOgMhLgCIiagCQhSgCgNgqQgLggAfg/QAZgzADgjQACgagIhiQgGhJgchDQgmhdgDgKQgoiVASgYQABgCAVAIQAiAMA6AEQCDAECDgYQAVgGgCAOQgBAIgIAYIgcC4QgHAtAAB3QAABsAFAvQABAIBLApQBbAwAWARQAcAXBPAaQBQAbAKAHQAXAQgNAOQgOAQgxAHQgfAFggAAIgggBg");
	this.shape_11.setTransform(260.2,305.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("ADwGVQhHgCh+gNQh1gNgtAAQhuAAgVgCQhAgDgLgSQgMgRALgoQAKglAWgeQASgZACggIgChQQgCg6gWhNIgriEQgzidAihKIAVAHQAdAHAmAFQB4ANCmgaIggDVQgdDsAWB3IAwAkQBRAwChA6IA4AWQA4AcgCAkQABADgRADQgVADguAAIg0gBg");
	this.shape_12.setTransform(260.8,302.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EFEFEF").s().p("AhLDeQgPgFgOgKQghgxgFg9QgCgVgGgdQgFgbgCgQIgChRIAKhiQACgSAfgPQAogUBKAAQBFAAAsATQAjAPAGARQALA9gFA5IgDAwQgDAmgCAPQgBAQgGAcIgLA4QgFAagSAZQgRAYgRAFQgcAHgvAAQgrgBgggGg");
	this.shape_13.setTransform(231,27.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#001423").s().p("AADAJQgQgLgQgOIAcAOQARAIANALQgPAAgLgIg");
	this.shape_14.setTransform(190.3,173.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AF/BdQhxhFiSgHQh7gGiWAlQgkAJgPABQgcADgZgJQg5gTgugcQgpgZgVgbQgNgQgEgRIgBgNIAwAkQA3AnAfAQQAmASAjAAQAmAABQgWQB4gcB6ACQBbAABmArQAtAVALACQAiADAEgxIANAdQAMAhgLAQQgIANgSAJQgLAGgHAAIgFgBg");
	this.shape_15.setTransform(238.2,95.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#EFEFEF").s().p("AAeGKIiDhLQifhZgehJQgZg+gBgiQgCgjAWgaQAugzAYhbQAUhPAggUQArgcArAVQAgAQAdAoQgLgugkgeQgigVAAgDQAAhDA4gyQAygtBIgNQAxgKAfABQAgAAAeALQAgALAgAFQAtAJgEBOQgFBLgrBGQgBABgMgSQgMgSgBABQgUAkgJAMQgDBEgiBBQgpBMg8AVQgRAGgSgBQgTgCgPgJQgngZgqgPQA3ArAdAlQAgAnAYA3QAdBIAYAqQApBKA9A/QgSAagMANQgUAXgWAJQgrgnhMgsg");
	this.shape_16.setTransform(169.9,111.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAXGdIiGhAQiehNgrhlQgag5gGgbQgNgyAUgWQAmgnAOgYQARggAThGQAWhRAvgfQAWgQArgGQAFhSA7g4QAzgwBOgQQBVgQBCAQQA/ARAgAsQAhAtgIA9QgJBAg0BHQAMBuhEBPQgwA3hBAYQAQAZAMAiIAUA+QAfBWBOBcQgOAggjAhQgmAlgmAKQgxgqhPgog");
	this.shape_17.setTransform(165.4,110.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AibHDQhigYARg5QAHgZAVgnQAVgnABgHQAEgbAFgVQAJgnAVgXQAUhCABhTQAAgigHhrQgJhZAFhRQAGhnAbg1QAmAZBBAVQBwAkCAgGQgGA+gHAaQgVBJg5BVQgkA0gYBQQgaBXgGBoQABAQAHAgQADAdgPAbQAFAQAUAmIAgA6QAQAggLAPQgQAXhJABIgXABQhfAAg+gQg");
	this.shape_18.setTransform(185.8,304.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAHAlQhigMhAACIgyAAQg+gHgUgWQgUgWAagdIJCAxQAEAcgrAQQgiAMg2ACQgigCiBgPg");
	this.shape_19.setTransform(262.3,341);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("ABbAsQjBgWg4ACQiiADgogdIABgWIABgXIAXgEIK3A4IgCAlQg5AKhGAAQhAAAhMgIg");
	this.shape_20.setTransform(262.7,341.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AARBPQiWgCgkhBIgIg0IAOgTQAPgUADAAQATACBuAiQB0AlA6AIIALACIAJAEIgGAzQgEAGgWAFQgmAKhGAAIgVgBg");
	this.shape_21.setTransform(179.5,346.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgaCRQgMAAgRgFQgigKgUgVQgEgOAIgLQgrgkgMgZQgSglAOgnQACgLAsghIBBgvQA1ACAyAQQAeAKANAMQAIAHAOASIAmAkQAWAagFASQgCAKgIAIIgSARQgzA3gKAGIgzAiQgRAJgKADQgJACgLAAIgJAAg");
	this.shape_22.setTransform(197.6,163.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#EFEFEF").s().p("Ak1J2QgQjRAlhhQARgqAjgwIBOhjQgkh0AChyQAFjZBykxQC+gpBzBhQBBA3ASBCQgXAYgaBbQgPAzgZBjQgaBrgtBJQg5BdhiBCQABAogXAhQgNAUgdAcQgYAcgHAmQAMgPANgLQAOgLAAAFQgDBvgSA6QgRA1g4BZg");
	this.shape_23.setTransform(211,225.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AlQJxQgCgHgCgcQgEg5AAhqQAAhsAvhMQAQgaAegmQAogvALgQQgsiwAvjVQAVheBakAQDKgsCHBmQBDAzAbA8QgTBFgXCjQgSB7gkBLQgqBchLBEQglAigdAPQgDAjgTAdQgKAQgPAQQAIBKgSBKQgSBEguBNQgXAmgUAZg");
	this.shape_24.setTransform(208,227.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#EFEFEF").s().p("AjPB3QglgogigyIgagqIARhJQALgsALgbIAIhGQEJAAEEAZQAEAlgIAgQABA8ANA8QAEAUANA3QAKAnAAAWQAABMheARQgiAGg6ABIhkABQgQAEgQAAQheAAhkhtg");
	this.shape_25.setTransform(235.7,168.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AjVBhQgygogxgzIgngpIARhDQAOgyAJgcQAFgJABgJQAMgRE4AbQCdAOCaAQIAEBcQAAAKAJAqQAJArAAAOQgWAohEAqQhZA4h2AVQgQAEgSAAQhjAAiHhtg");
	this.shape_26.setTransform(233.5,170.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#EFEFEF").s().p("ABBGmQiagNhpgFQgXhegJhfQAngSAcghQgtAHgZgCQgYgEgcgPQgagPgrgpQgogngaghQgIAOgNAQQgZAigfABQgJgOAegyQAfgzgHgOQgghCAjirIAqifQAsAOAxAEQBNAFBIgHQBpgIA8ADQBlAGA9AiQA0gPA2ADQANABAYAMQAcAOAMADQBHATAuBcQAvBigbBhQgCAFgUAAQgbAAgQAFQAOBUglBOQglBLgOA0QgaBbAGBwQhsgFiagMg");
	this.shape_27.setTransform(230.4,107.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#EFEFEF").s().p("AhJLeQgEgxgJg9QgRh8gbhBIgvhXQgeg3gCgwQgEg5Aig5QAphDBFACQgChPgUg/IgshwQhDipgSkfIGGhbIAdCqQARBsADBMQALDWhYBiQAMA7gKA4QgIAogPAnQgNAggJA0QgEAVgIA6QgUB9gFA9QgFA3gJDPg");
	this.shape_28.setTransform(247.9,245.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AhOLUQgEgxgJg9QgSh8gahBQgFgMhAhaQgyhFACgvQAEg2ATgjQAagxBHg4QADgjgQg4QgXhJgNgxQg1jFALkDIGphFIASBJQATBbAIBWQAaERhdB2QAIAvgHAuQgHAvgXApIgNA7QgIAjgEAYIgvDZQgdCEgHCig");
	this.shape_29.setTransform(248.4,246.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("ABDG8QjWgeiJADIAGhFIAGAAIgOhTQgHgngIgfQhJgugsgnQhAg4gvhIQgqhEBPjKQAZhAAhhEIAdg5IBHAUQBSATA9gEQBqgJBKAFQByAGA8AiIA4gNQBDgKA2ANQBPAVBEBcQBQBqggBpQgDAIgRALQgSALgXAHIAFAqQABAwgSAjQgrBSgOAmQgjBegCBeQgGBNgEAXQg0gCjvggg");
	this.shape_30.setTransform(230.5,111.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#88CE02").s().p("AhDAPIgogfQANgKgFgCQAXgNAOAAQAVAAAJAZQAfgKAPAKIAdAeQAlgQAPALQAHAFAGAUQgrABgmAFIgPACQglAAgqgbg");
	this.shape_31.setTransform(270,70.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AhEApQglggAAABQAAgVgCgVQAAgCgIgHQgIgHAAgCIgEgEIATgIQAXgGAPAGQAQAFAOATQAHAKAEAJQAdgLAPAJQAEACAYAZQAhgGAQAMQAJAGAbApQgJgBgSAAQgkgBgtAIIgOABQgjAAgngZg");
	this.shape_32.setTransform(270.6,68.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#88CE02").s().p("AkmA+QAsg+BIgWQAcgLAUADQARADAXAPQgKgRgKgMQAQgIAagRQAWgLATADQAXAFAXARQAVAOAQARQgKgZgRgRQALgHAUgRQASgMASABQBVAHAtAsQAMAMAUAWQASARAUAHIizApQhtAZhpANQhGAJgtAAQhcAAAKglg");
	this.shape_33.setTransform(192.1,65.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AkvA0QAsg6A+gUQATgHAWgBQAVgBAJAFQAPgGASgMIAggVQAQgJAdAIQAUAFAOAIQARgKAdgUQAYgOAVAGQA7APAyAiQAyAhAlAvIixApQhyAQhuAFQgkACgeAAQiaAAANgug");
	this.shape_34.setTransform(190.8,63);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#EFEFEF").s().p("AhEH0QgYgGgagQIg+glQgUgLABgTQAFgUAAgJQACgKAIgIQAMgYAXgVIASgSQAXgSAYABQAcACAbgFQAbgFAHgIQAAgXgMgVIgYgjQghgvARhGQAFgPAogFQgvgJgMgFQgYgIgXgWQgogigJg1QgHgogOi1IgLiuIAYgLQAfgLAegFQBggQA2A1QA7A5ACBJQACAygaBAQAcAhAOAnQAWA+gVA6QgDAHgdARQghASgTAeQA8giAnAHQAmAGAOAtQATA/ghBQQgaBCgyA2IgCgGQgMAugIATQgVAwgnAqQgVAXgVADIgIAAQgOAAgZgGg");
	this.shape_35.setTransform(283.3,126.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AA2GQQgqg2hHgEQABgMgPgTQgVgVgKgNQgog0Aeg+QgzgMgRgnQgGgMgOhKQgGgoAQjcIARjVIAVgEQAbgDAbABQBWAHA2A0QA0AxAPBGQAQBGgcBDQAgAoAIAxQAJAygQAvQBeBSgVB5QgUBshiBfQgHgbgWgbg");
	this.shape_36.setTransform(286.6,118.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AApCCIgOgXQgCgDgJgFQgKgFgDgDIgFgMQgDgIgGgFQgEgEgHAAQgHgBgEgDQgEgEgFgJQgEgIgDgDQgCgCgKgDQgLgDgCgCQgCgCgzgTQgtgPADgMQAHgeARgXIAYgcQAdgcAYABIA3ADQAbAAANgLQAUgSA+AuQBBAvgEAtQgKAegTAkQgmBJgvAbQgKgFgFgLg");
	this.shape_37.setTransform(278.5,165.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("ACqCLQAMgogCgnQgBgVgEgQQgDgHAEgHQAKgPABgIQABgQgYgNQgVgLgxAMQhFARgZABQgbgBhDgRQgxgMgUALQgYANABAQQABAJAKAOQADAGgCAHQgEAQgBAWQgCAqAMAlIgTAAQgLhtgDgkQgDgwAFgHQAogqAYgMQAvgXBZgBQBbACAwAXQAgAQAgApQADAGgEAwIgOCOg");
	this.shape_38.setTransform(231,17);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AhKDMQgQgFgNgIIgtgiQgigaAAgTQAMh1gQh2QgEgOAGgQQAMgfAxgJQA/gMA8gEQA+ACA+AOQAxAJAMAfQAGAQgEAOQgQB2AMB1QAAASgiAbIgnAdQgVAPgOACQgjAHgoAAQglAAglgGg");
	this.shape_39.setTransform(230.9,29.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAzBlIgygBQgxAAgLgBQgfgCgMgLQgQgOgbgbIgsgtQADgaADgdIACgXQAlgWCiAAQCkAAADAWQACARADBFQgUAZgeAYQggAbgYAMQgHAFgWAAIgEAAg");
	this.shape_40.setTransform(230.6,42.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EFEFEF").s().p("AijB4QgMhBgpg3QgmgqABgHQAHggACgfQAEgjABgsIABglQAkgVCJAEQCJAFADAXQAEAZAEAyQAFA4ABAoQABAcgCAjQAAAYATAHQBNAfBGAvQhZBjh2ASQgUADgSAAQhzAAg5h+g");
	this.shape_41.setTransform(238.3,57.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AAHDTQh5gNhYguQhlg1gehWQASgIA0gMQAlgJABgHQAQhVAGhUQAlgWClAAQCjAAADAWQAFAfAFCgQACArADAHQADAIAXAJQBDAdA9AoQgZAshgAWQg9AOhFAAQglAAgngEg");
	this.shape_42.setTransform(232.7,54.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AANCPQg4gGhIgnQgWgNgSglQgRgiACgRQAAgrAhgcIAVgbQAagbAYABQA2ADAOgBQAqgBANgLQARgSAxAlQAzAmgDAuQgJAhgUAmQgmBNgxAbQgJADgOAAIgTgBg");
	this.shape_43.setTransform(278.3,166.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#88CE02").s().p("AuCDDQBxh6C2hvQF8jqHziWQBPgXFMhbQD4hDCbg2QAKAsAHBFQALBbAJA7Qi3BHjlBJIm5CJQnQCRmJDdQlsDOizDHQAnkDC9jMg");
	this.shape_44.setTransform(117.8,117.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#88CE02").s().p("AC1MBQiLiHjzAGQj/AGh7hpQhzhhgUjUQgakDhuhuQiKiLjzCNQBEiBEJiTQCuhhDLhNQDKhODyhNQCFgrDmhGQC4g7BmgsQCCg5BOhDQBIgaByBWQBzBXBMCLQBVCcgLCTQgMCtiUB4QiUB3gTARQhpBfhSB2QjfFEh+JlQhcjjhfhcg");
	this.shape_45.setTransform(148.8,159.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("ACoGuQiBgPgcAAQh0ADhEgCQh8gEghgXQgmgbgCgyIAFgtQAZhEAIggQAUhKgIg1QgIg3gOgvQgLgigahAQgYg8gKhkQgLhoAVgHQARgGAIADIAgALQBLAVBSgBQBjgBBhgRQAegGAIAFQAOAJgHArQgFAfgTBfQgSBbgBA4QgEC+AIAZQAEALAcASIA0AgQBLA2BaAlIB2AvQAyAagQAlQgQAmhNAOQgWAEghAAQgpAAg5gGg");
	this.shape_46.setTransform(260.7,304.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AiuDIQgMgNgKg+IgHg7QgJg5AGhZQAHhZAMgTQATgZA2gPQAygOBAAAQCUgBApA7QAcArgKCGIgKBvQgJBQgBAUQAAALgwALQgwAMg9AEQgbABgWAAQh3AAgkgrg");
	this.shape_47.setTransform(230.9,24.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AiCGwQg1gRgdgbQgYgWgCgqQgDgrAXgqIAagsQAPgXAGgbQAHgkATghQAGgLADgVQACgXABhIIACi/QACh/AGgxQAHgzCyAnQBZAUBYAdIgsBuIg+CVQgOAggEBAQgCAXAAAxQAAAQgFAWQgFAXgEACQgCAAAIAgQAJAjgHASQgFASALAuIAOA3QANBQgTAWQgSAThYALQgWADgXAAQgzAAgxgQg");
	this.shape_48.setTransform(184.4,311.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("As3J9QgMgFgDgdQgHhEAqh7QAkhxBUh3QBfiJCHhvQBKg9CmhfQB3hECVhNQA5geDUhOQEchpDhg2QARgEgZAfQgiAqgFAPQghBgoeFzQkNC4kJCmIgiATQhLAjigB+QibB5gqA0QgRATgMAAIgFAAg");
	this.shape_49.setTransform(84,127.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.instance_5},{t:this.instance_4},{t:this.shape_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(0,0,307.1,355.9), null);


// stage content:
(lib.GSAP_Basic_2017 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var tl = new TimelineMax({repeat:3, repeatDelay:1});
		
		tl.from(this.logo_mc, 0.5, {scaleX:0, scaleY:0, alpha:0, ease:Back.easeOut})
		  .from(this.GreenSock_mc, 0.4, {y:"+=70", alpha:0, ease:Back.easeOut}, "-=0.3")
		  .from(this.subtitle_mc, 0.5, {alpha:0}, "+=0.3")
		
		
		console.log(TweenLite.version);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo
	this.logo_mc = new lib.logo_mc();
	this.logo_mc.parent = this;
	this.logo_mc.setTransform(265.5,123,0.54,0.54,0,0,0,160.3,175);

	this.timeline.addTween(cjs.Tween.get(this.logo_mc).wait(1));

	// GreenSock
	this.GreenSock_mc = new lib.greensock_mc();
	this.GreenSock_mc.parent = this;
	this.GreenSock_mc.setTransform(274,248,0.311,0.311,0,0,0,389.6,65.8);

	this.timeline.addTween(cjs.Tween.get(this.GreenSock_mc).wait(1));

	// subtitle
	this.subtitle_mc = new lib.subtitle();
	this.subtitle_mc.parent = this;
	this.subtitle_mc.setTransform(275.6,372.1);

	this.timeline.addTween(cjs.Tween.get(this.subtitle_mc).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#252525","#000000"],[0,1],0,24.1,0,0,24.1,340.1).s().p("Egq9AfQMAAAg+fMBV7AAAMAAAA+fg");
	this.shape.setTransform(275,200);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(275,200,550,400.1);
// library properties:
lib.properties = {
	width: 550,
	height: 400,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;